/**
 * Class name: LoanAccountController
 * 
 * Desc: Controller class for Loan Account
 *
 * Date : 15/10/2020
 * 
*/
package com.ust.training.bankmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ust.training.bankmanagement.model.CurrentAccount;
import com.ust.training.bankmanagement.model.LoanAccount;
import com.ust.training.bankmanagement.model.SBAccount;
import com.ust.training.bankmanagement.service.LoanAccountService;

/** for mapping Loan account operations */
@Controller
public class LoanAccountController {
	
	/* autowiring Loan account service object */
	@Autowired
	LoanAccountService laService;
	
	/* Creating new  Loan account  */
	@RequestMapping("/viewloanaccountform")
	public String viewLoanAccountForm(Model model) {
		
		LoanAccount la = new LoanAccount();
		model.addAttribute("loanaccounts2", la);
		
		return "addLoanAccount";
	}
	
	
	@RequestMapping("/addloanaccount")
	public String addLoanAccount(@ModelAttribute("loanAccount") LoanAccount la) {
		
		laService.addLoanAccount(la);
		
		return "redirect:/allloanaccounts";
	}
	
	/* updating  Loan account  */
	@RequestMapping("/updateloanaccount")
	public String updateLoanAccount(@ModelAttribute("loanAccount") LoanAccount la) {
		
		laService.updateLoanAccount(la);
		return "redirect:/allloanaccounts";
	}
	
	/* getting all Loan account details */
	@RequestMapping("/allloanaccounts")
	public String getAllLoanAccounts(Model model) {
		
		List<LoanAccount> la = laService.getAllLoanAccounts();
		model.addAttribute("loanaccounts", la);
		
		return "loanAccount";
	}
	
	/* getting specific Loan account details */
	@RequestMapping("/viewloanaccount")
	public String getLoanAccountByAccountNumber(@RequestParam("acno") int acno, Model model) {
		
		LoanAccount la = laService.getLoanAccountByAccountNumber(acno);
		model.addAttribute("loanaccounts1", la);
		
		return "viewLoanAccount";
		
	}
	
	/* deleting specific Loan account details */
	@RequestMapping("/deleteloanaccount")
	public String deleteLoanAccountByAccountNumber(@RequestParam("acno") int acno) {
		
		laService.deleteLoanAccount(acno);
		
		return "redirect:/allloanaccounts";
		
	}
	
	
	/* sort Loan account by A/c holder name */
	@RequestMapping("/sortloanaccountbyname")
	public String getAllLoanAccountsSortedByName(Model model) {
		
		List<LoanAccount> sorted = laService.getAllLoanAccountsSortedByName();
		model.addAttribute("loanaccounts", sorted);
		return "loanAccount";
	}
	
	/* sort SB account by loan outstanding */
	@RequestMapping("/sortloanaccountbyloanout")
	public String getAllSBAccountsSortedByBalance(Model model) {
		
		List<LoanAccount> sorted = laService.getAllLoanAccountsSortedByLoanOutstanding();
		model.addAttribute("loanaccounts", sorted);
		return "loanAccount";
	}

}
