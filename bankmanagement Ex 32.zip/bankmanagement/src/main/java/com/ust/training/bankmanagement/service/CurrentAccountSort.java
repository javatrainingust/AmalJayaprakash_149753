
package com.ust.training.bankmanagement.service;

import com.ust.training.bankmanagement.model.CurrentAccount;


public class CurrentAccountSort {
	
public static void main(String args[]) {
		
		CurrentAccountService currentAccountService = new CurrentAccountService();
		currentAccountService.addCurrentAccount(new CurrentAccount(100, "anu",5000));
		currentAccountService.addCurrentAccount(new CurrentAccount(101, "manu",2000));
		currentAccountService.addCurrentAccount(new CurrentAccount(102, "binu",3000));
		
		System.out.println("All current accounts");
		currentAccountService.getAllCurrentAccounts();
		
		System.out.println();
		
		System.out.println("current accounts sorted by a/c holder name");
		currentAccountService.getAllCurrentAccountsSortedByName();
		
		System.out.println();
		
		System.out.println("current accounts sorted by overdraft limit");
		currentAccountService.getAllCurrentAccountsSortedByOverdraftLimit();
	}

}
