/**
 * Class name: HomeController
 * 
 * Desc: Controller class for Home
 *
 * Date : 15/10/2020
 * 
*/
package com.ust.training.bankmanagement.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
/** for mapping to home page */
@Controller
public class HomeController {
	
	@RequestMapping("/home")
	public String home() {
		
		return "home";
	}

}
