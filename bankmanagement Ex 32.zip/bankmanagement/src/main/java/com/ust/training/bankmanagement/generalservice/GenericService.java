package com.ust.training.bankmanagement.generalservice;

import com.ust.training.bankmanagement.model.Account;
import com.ust.training.bankmanagement.model.FDAccount;


/**...
 * GenericService
 * for finding simple interest by interface by programming
 * 30/09/2020
 * */
public class GenericService {
	
	public static void main(String args[]) {
		
	
		FDAccount fdAccount = new FDAccount();
		fdAccount.setAccountHolderName("Rejin");
		fdAccount.setAccountNumber(296);
		fdAccount.setPrincipal(1000);
		fdAccount.setRate(6);
		fdAccount.setAutoRenewal(false);
		System.out.println("a/c holder :"+fdAccount.getAccountHolderName());
		System.out.println("a/c no :"+fdAccount.getAccountNumber());
		
	
		//down casting
	
		Account[] account = {new Account(),fdAccount};
		
		for(Account a : account) {
			
			a.calculateInterest();
			if(a instanceof FDAccount){
				
				FDAccount fd = (FDAccount) a;
				
				
				fd.autoRenewal(12); 
			}
		}
	
	
	}

}
