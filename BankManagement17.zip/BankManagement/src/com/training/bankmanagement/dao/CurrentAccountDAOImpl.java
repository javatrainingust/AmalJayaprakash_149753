/**
 * Classname:CurrentAccountDAOImpl
 * 
 * Description:This class is implemented from CurrentAccountAccountDAO for data access operations
 *
 * Date:06/10/2020
 * 
*/
package com.training.bankmanagement.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.training.bankmanagement.model.CurrentAccount;


/**
*This is a class used for add,delete,get the current account detalis.
*/
public class CurrentAccountDAOImpl implements CurrentAccountDAO{
	
	List<CurrentAccount> currentAccountList;
	/**
	*constructor for SBAccountDAOImpl
	*/
	public CurrentAccountDAOImpl() {
		
		currentAccountList = new ArrayList<CurrentAccount>();
		
		currentAccountList.add(new CurrentAccount(100, "anu",4000));
		currentAccountList.add(new CurrentAccount(101, "manu",1000));
		currentAccountList.add(new CurrentAccount(102, "vinu",2000));
		
	}
	/**
	*method for getting all current accounts
	*method implemented from CurrentAccountDAO
	*/
	@Override
	public List<CurrentAccount> getAllCurrentAccounts() {
		// TODO Auto-generated method stub
		return currentAccountList;
	}
	/**
	*method for getting current account details by account number
	*method implemented from CurrentAccountDAO
	*/
	@Override
	public CurrentAccount getCurrentAccountByAccountNumber(int accountNumber) {
		// TODO Auto-generated method stub
		CurrentAccount currentAccount = null;
		Iterator<CurrentAccount> iterator = currentAccountList.iterator();
		while(iterator.hasNext()) {
			
			CurrentAccount ca = iterator.next();
			
			if(ca.getAccountNumber() == accountNumber) {
				
				currentAccount = ca;
			}
		}
		return currentAccount;
	}
	/**
	*method for deleting current  account by account number
	*method implemented fromCurrentAccountDAO
	*/
	@Override
	public void deleteCurrentAccount(int accountNumber) {
		// TODO Auto-generated method stub
		for(int i = 0; i < currentAccountList.size(); i++) {
			
				CurrentAccount ca = currentAccountList.get(i);
				if(ca.getAccountNumber() == accountNumber) {
				
					currentAccountList.remove(i);
			}
		}
		
	}

}
