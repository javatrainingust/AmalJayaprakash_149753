/**
 * Interface name:CurrentAccountDAO
 * 
 * Description:This interface is form data access operations
 *
 * Date:06/10/2020
 * 
*/
package com.training.bankmanagement.dao;

import java.util.List;

import com.training.bankmanagement.model.CurrentAccount;


public interface CurrentAccountDAO {
	
	public List<CurrentAccount> getAllCurrentAccounts();
	public CurrentAccount getCurrentAccountByAccountNumber(int accountNumber);
	public void deleteCurrentAccount(int accountNumber);

}
