package com.training.bankmanagement.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.training.bankmanagement.dao.LoanAccountDAOImpl;
import com.training.bankmanagement.model.CurrentAccount;
import com.training.bankmanagement.model.LoanAccount;
import com.training.bankmanagement.service.LoanAccountService;

public class LoanAccountTest {

List<LoanAccount> loanList;
	
    public LoanAccountTest() {
	
    	loanList = new ArrayList<LoanAccount>();
    	loanList.add(new LoanAccount(100,"anu"));
    	loanList.add(new LoanAccount(101,"manu"));
    	loanList.add(new LoanAccount(102,"vinu"));
}
	

	@Test
	public void testGetAllLoanAccounts() {
		LoanAccountDAOImpl loanAccountDAOImpl = new LoanAccountDAOImpl();
		int actual = loanAccountDAOImpl.getAllLoanAccounts().size();
		int expected = loanList.size();
		assertEquals(expected, actual);
	}
	
	@Test
	public void testGetLoanAccountByAccountNumber() {
		LoanAccountDAOImpl loanAccountDAOImpl = new LoanAccountDAOImpl();
		String actual = loanAccountDAOImpl.getLoanAccountByAccountNumber(100).getAccountHolderName();
		String expected = loanList.get(0).getAccountHolderName();
		assertEquals(expected, actual);
	}
	
	@Test
	public void testDeleteLoanAccount() {
		LoanAccountDAOImpl loanAccountDAOImpl = new LoanAccountDAOImpl();
		loanAccountDAOImpl.deleteLoanAccount(102);;
		LoanAccount actual = loanAccountDAOImpl.getLoanAccountByAccountNumber(102);
		System.out.println(actual); 
		CurrentAccount expected = null;
		assertEquals(expected, actual);
	}
	
	@Test
	public void testGetAllLoanAccountsSortByName() {
		LoanAccountService loanAccountService = new LoanAccountService();
		String actual = loanAccountService.getAllLoanAccountsSortedByName().get(0).getAccountHolderName();
		String expected = "anu";
		assertEquals(expected, actual);
	}
	
	@Test
	public void testGetAllCurretAccountsSortByLoanOutstanding() {
		LoanAccountService loanAccountService = new LoanAccountService();
		String actual = loanAccountService.getAllLoanAccountsSortedByLoanOutstanding().get(0).getAccountHolderName();
		System.out.println(actual);
		String expected = "manu";
		assertEquals(expected, actual);
	}

}
