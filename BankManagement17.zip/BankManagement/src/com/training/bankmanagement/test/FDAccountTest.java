package com.training.bankmanagement.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.training.bankmanagement.dao.FDAccountDAOImpl;
import com.training.bankmanagement.model.FDAccount;
import com.training.bankmanagement.service.FDAccountService;

public class FDAccountTest {
	
	List<FDAccount> fdList;
	
    public FDAccountTest() {
	
    	fdList = new ArrayList<FDAccount>();
    	fdList.add(new FDAccount(100,"anu",3000));
    	fdList.add(new FDAccount(101,"manu",1000));
    	fdList.add(new FDAccount(102,"vinu",5000));
}
	

	@Test
	public void testGetAllFDAccounts() {
		FDAccountDAOImpl fdAccountDAOImpl = new FDAccountDAOImpl();
		int actual = fdAccountDAOImpl.getAllFDAAccounts().size();
		int expected = fdList.size();
		assertEquals(expected, actual);
	}
	
	@Test
	public void testGetFDAccountByAccountNumber() {
		FDAccountDAOImpl fdAccountDAOImpl = new FDAccountDAOImpl();
		String actual = fdAccountDAOImpl.getFDAAccountByAccountNumber(100).getAccountHolderName();
		String expected = fdList.get(0).getAccountHolderName();
		assertEquals(expected, actual);
	}
	
	@Test
	public void testDeleteFDAccount() {
		FDAccountDAOImpl fdAccountDAOImpl = new FDAccountDAOImpl();
		fdAccountDAOImpl.deleteFDAAccount(102);;
		FDAccount actual = fdAccountDAOImpl.getFDAAccountByAccountNumber(102);
		System.out.println(actual); 
		FDAccount expected = null;
		assertEquals(expected, actual);
	}
	
	@Test
	public void testGetAllFDAccountsSortByName() {
		FDAccountService fdAccountService = new FDAccountService();
		String actual = fdAccountService.getAllFDAccountsSortedByName().get(0).getAccountHolderName();
		String expected = "anu";
		assertEquals(expected, actual);
	}
	
	@Test
	public void testGetAllFDAccountsSortByBalance() {
		FDAccountService fdAccountService = new FDAccountService();
		String actual = fdAccountService.getAllFDAccountsSortedByBalance().get(0).getAccountHolderName();
		System.out.println(actual);
		String expected = "manu";
		assertEquals(expected, actual);
	}

}
