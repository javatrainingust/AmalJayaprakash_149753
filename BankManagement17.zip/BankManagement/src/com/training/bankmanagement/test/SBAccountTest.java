package com.training.bankmanagement.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.training.bankmanagement.dao.SBAccountDAOImpl;
import com.training.bankmanagement.model.FDAccount;
import com.training.bankmanagement.model.SBAccount;
import com.training.bankmanagement.service.SBAccountService;

public class SBAccountTest {

List<SBAccount> sbList;
	
    public SBAccountTest() {
	
    	sbList = new ArrayList<SBAccount>();
    	sbList.add(new SBAccount(100,"anu"));
    	sbList.add(new SBAccount(101,"manu"));
    	sbList.add(new SBAccount(102,"vinu"));
}
	

	@Test
	public void testGetAllSBAccounts() {
		SBAccountDAOImpl sbAccountDAOImpl = new SBAccountDAOImpl();
		int actual = sbAccountDAOImpl.getAllSBAccounts().size();
		int expected = sbList.size();
		assertEquals(expected, actual);
	}
	
	@Test
	public void testGetSBAccountByAccountNumber() {
		SBAccountDAOImpl sbAccountDAOImpl = new SBAccountDAOImpl();
		String actual = sbAccountDAOImpl.getSBAccountByAccountNumber(100).getAccountHolderName();
		String expected = sbList.get(0).getAccountHolderName();
		assertEquals(expected, actual);
	}
	
	@Test
	public void testDeleteSBAccount() {
		SBAccountDAOImpl sbAccountDAOImpl = new SBAccountDAOImpl();
		sbAccountDAOImpl.deleteSBAccount(102);;
		SBAccount actual = sbAccountDAOImpl.getSBAccountByAccountNumber(102);
		System.out.println(actual); 
		FDAccount expected = null;
		assertEquals(expected, actual);
	}
	
	@Test
	public void testGetAllSBAccountsSortByName() {
		SBAccountService sbAccountService = new SBAccountService();
		String actual = sbAccountService.getAllSBAccountsSortedByName().get(0).getAccountHolderName();
		String expected = "anu";
		assertEquals(expected, actual);
	}
	
	@Test
	public void testGetAllSBAccountsSortByBalance() {
		SBAccountService sbAccountService = new SBAccountService();
		String actual = sbAccountService.getAllSBAccountsSortedByBalance().get(0).getAccountHolderName();
		System.out.println(actual);
		String expected = "vinu";
		assertEquals(expected, actual);
	}

}
