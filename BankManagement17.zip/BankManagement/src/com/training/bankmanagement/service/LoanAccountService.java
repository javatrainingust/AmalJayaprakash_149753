/**
 * Classname:LoanAccountService
 * 
 * Description:This class forms sevices from data access class 
 *
 * Date:06/10/2020
 * 
*/
package com.training.bankmanagement.service;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.training.bankmanagement.dao.LoanAccountDAO;
import com.training.bankmanagement.dao.LoanAccountDAOImpl;
import com.training.bankmanagement.model.LoanAccount;

/**
*This is a class used for add,delete,get the loan account detalis using data access class object.
*/
public class LoanAccountService {

	
	LoanAccountDAO loanAccountDAO;
	
	public LoanAccountService() {
			
		loanAccountDAO = new LoanAccountDAOImpl();
		}
		/**
		*method for getting all loan accounts using data access class object
		*
		*/
		public List<LoanAccount> getAllLoanAccounts() {
			
			List<LoanAccount> loanAccountList = loanAccountDAO.getAllLoanAccounts();
			
			Iterator<LoanAccount> iterator = loanAccountList.iterator();
			
			while(iterator.hasNext()) {
				
				LoanAccount la = iterator.next();
				System.out.println("A/c no: "+la.getAccountNumber());
				System.out.println("A/c holder name: "+la.getAccountHolderName());
				System.out.println("Loan out standing: "+la.getLoanOutStanding());
			}
			return loanAccountList;
		}
		/**
		*method for getting loan account details by account number using data access class object
		*
		*/
		public LoanAccount getLoanAccountByAccountNumber(int accountNumber) {
			
			LoanAccount la = loanAccountDAO.getLoanAccountByAccountNumber(accountNumber);
			System.out.println("A/c no: "+la.getAccountNumber());
			System.out.println("A/c holder name: "+la.getAccountHolderName());
			System.out.println("Loan out standing: "+la.getLoanOutStanding());
			
			return la;
		}
		/**
		*method for deleting loan account by account number using data access class object
		*
		*/
		public void deleteLoanAccount(int accountNumber) {
			loanAccountDAO.deleteLoanAccount(accountNumber);
		}
		
		/**
		*method for sorting loan account by a/c holder name
		*
		*/
		public List<LoanAccount> getAllLoanAccountsSortedByName() {
			
			List<LoanAccount> loanSortedList = loanAccountDAO.getAllLoanAccounts();
			Collections.sort(loanSortedList);
			
			Iterator<LoanAccount> iterator = loanSortedList.iterator();
			while(iterator.hasNext()) {
				
				LoanAccount la = iterator.next();
				System.out.println("A/c no: "+la.getAccountNumber());
				System.out.println("A/c holder name: "+la.getAccountHolderName());
				System.out.println("Loan outstanding : "+la.getLoanOutStanding());
			}
			return loanSortedList;
			
			
		}
		
		/**
		*method for sorting loan account by loan outstanding
		*
		*/
		public List<LoanAccount> getAllLoanAccountsSortedByLoanOutstanding() {
			
			List<LoanAccount> loanSortedList = loanAccountDAO.getAllLoanAccounts();
			Collections.sort(loanSortedList, new LoanAccountComparator());
			
			Iterator<LoanAccount> iterator = loanSortedList.iterator();
			while(iterator.hasNext()) {
				
				LoanAccount la = iterator.next();
				System.out.println("A/c no: "+la.getAccountNumber());
				System.out.println("A/c holder name: "+la.getAccountHolderName());
				System.out.println("Loan outstanding : "+la.getLoanOutStanding());
			}
			return loanSortedList;
			
			
		}
		


}
