/**
 * Classname:FDAccountService
 * 
 * Description:This class forms sevices from data access class 
 *
 * Date:06/10/2020
 * 
*/
package com.training.bankmanagement.service;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.training.bankmanagement.dao.FDAccountDAO;
import com.training.bankmanagement.dao.FDAccountDAOImpl;
import com.training.bankmanagement.model.FDAccount;
/**
*This is a class used for add,delete,get the fixed account detalis using data access class object.
*/
public class FDAccountService {
	
	FDAccountDAO fdAccountDAO;
	
	public FDAccountService() {
		
		fdAccountDAO = new FDAccountDAOImpl();
	}
	/**
	*method for getting all fixed accounts using data access class object
	*
	*/
	public List<FDAccount> getAllFDAAccounts() {
		
		List<FDAccount> fdAccountList = fdAccountDAO.getAllFDAAccounts();
		
		Iterator<FDAccount> iterator = fdAccountList.iterator();
		
		while(iterator.hasNext()) {
			
			FDAccount fd = iterator.next();
			System.out.println("A/c no: "+fd.getAccountNumber());
			System.out.println("A/c holder name: "+fd.getAccountHolderName());
			System.out.println("A/c balance: "+fd.getBalance());
		}
		return fdAccountList;
	}
	/**
	*method for getting fixed account details by account number using data access class object
	*
	*/
	public FDAccount getFDAAccountByAccountNumber(int accountNumber) {
		
		FDAccount fd = fdAccountDAO.getFDAAccountByAccountNumber(accountNumber);
		System.out.println("A/c no: "+fd.getAccountNumber());
		System.out.println("A/c holder name: "+fd.getAccountHolderName());
		System.out.println("A/c balance: "+fd.getBalance());
		
		return fd;
	}
	/**
	*method for deleting fixed account by account number using data access class object
	*
	*/
	public void deleteFDAAccount(int accountNumber) {
		fdAccountDAO.deleteFDAAccount(accountNumber);
	}
	
	/**
	*method for sorting fixed account by a/c holder name
	*
	*/
	public List<FDAccount> getAllFDAccountsSortedByName() {
		
		List<FDAccount> fdSortedList = fdAccountDAO.getAllFDAAccounts();
		Collections.sort(fdSortedList);
		
		Iterator<FDAccount> iterator = fdSortedList.iterator();
		while(iterator.hasNext()) {
			
			FDAccount fd = iterator.next();
			System.out.println("A/c no: "+fd.getAccountNumber());
			System.out.println("A/c holder name: "+fd.getAccountHolderName());
			System.out.println("A/c balance: "+fd.getBalance());
		}
		return fdSortedList;
		
		
	}
	
	/**
	*method for sorting fixed account by a/c balance
	*
	*/
	public List<FDAccount> getAllFDAccountsSortedByBalance() {
		
		List<FDAccount> fdSortedList = fdAccountDAO.getAllFDAAccounts();
		Collections.sort(fdSortedList, new FDAccountComparator());
		
		Iterator<FDAccount> iterator = fdSortedList.iterator();
		while(iterator.hasNext()) {
			
			FDAccount fd = iterator.next();
			System.out.println("A/c no: "+fd.getAccountNumber());
			System.out.println("A/c holder name: "+fd.getAccountHolderName());
			System.out.println("A/c balance: "+fd.getBalance());
		}
		return fdSortedList;
		
		
	}
	
	

}
