package com.training.bankmanagement.service;

public class SBAccountSort {
	
	public static void main(String args[]) {
		
		SBAccountService sbAccountService = new SBAccountService();
		System.out.println("All SB accounts");
		sbAccountService.getAllSBAccounts();
		
		System.out.println();
		
		System.out.println("SB accounts sorted by a/c holder name");
		sbAccountService.getAllSBAccountsSortedByName();
		
		System.out.println();
		
		System.out.println("SB accounts sorted by balance");
		sbAccountService.getAllSBAccountsSortedByBalance();
	}

}
