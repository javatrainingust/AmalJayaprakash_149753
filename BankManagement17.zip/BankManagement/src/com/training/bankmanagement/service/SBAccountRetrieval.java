package com.training.bankmanagement.service;

public class SBAccountRetrieval {
	
public static void main(String[] args) {
		
		SBAccountService sbAccountService = new SBAccountService();
		System.out.println("all savings accounts");
		sbAccountService.getAllSBAccounts();
		System.out.println();
		System.out.println("savings account details");
		sbAccountService.getSBAccountByAccountNumber(100);
		
	}

}
