/**
 * Classname:SBAccount
 * 
 * Description:This is a sub class of Account
 *
 * Date:30/09/2020
 * 
*/
package com.bankmanagement.model;

import com.bankmanagement.util.InterestCalculator;

/**
*This is a class used to model Savings bank  account operations.
*/
public class SBAccount extends Account{
	
	private double interest;
	private float rate;
	private float principal;
	

	/**
	*no arg constructor for SBAccount
	*/
	public SBAccount() {
		
	}
	
	/**
	*param  constructor for SBAccount
	*/
	public SBAccount(int accountNumber, String accountHolderName,float rate, float principal) {
		super(accountNumber, accountHolderName);
		this.rate = rate;
		this.principal = principal;
	}




	public float getPrincipal() {
		return principal;
	}




	public void setPrincipal(float principal) {
		this.principal = principal;
	}




	public double getInterest() {
		return interest;
	}




	public void setInterest(double interest) {
		this.interest = interest;
	}




	public double getRate() {
		return rate;
	}




	public void setRate(float rate) {
		this.rate = rate;
	}




	/**
	*overriding method from Account class
	*method for finding interest
	*/
	
	@Override
	public void calculateInterest() {
		
		intr = (principal*rate*1)/100;
		System.out.println(" interest at SB:" +intr);
	}



	/**
	*method for finding simple interest
	*/
	public void calculateSimpleInterest(InterestCalculator interestCalculator) {
		 
		 this.simpleIntr = interestCalculator.calculateSimpleInterest(rate);
		 System.out.println("Interest in SB: "+simpleIntr);	 }



}
