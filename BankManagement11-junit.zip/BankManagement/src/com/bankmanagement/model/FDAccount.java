/**
 * Classname:FDAccount
 * 
 * Description:This is a sub class of Account class and implemented from Renewable
 *
 * Date:30/09/2020
 * 
*/
package com.bankmanagement.model;

import com.bankmanagement.util.InterestCalculator;

/**
*This is a class used to model Fixed deposit account operations.
*/
public class FDAccount extends Account implements Renewable{
	
	
	 private boolean isAutoRenewal;
	 private float rate;
	 private float principal;
	 private float additional;
	 
	 
	public float getRate() {
		return rate;
	}
	
	public float getAdditional() {
		return additional;
	}

	public void setAdditional(float additional) {
		this.additional = additional;
	}

	public float getPrincipal() {
		return principal;
	}




	public void setPrincipal(float principal) {
		this.principal = principal;
	}


	public void setRate(float rate) {
		this.rate = rate;
	}

	public boolean isAutoRenewal() {
		return isAutoRenewal;
	}
	public void setAutoRenewal(boolean isAutoRenewal) {
		this.isAutoRenewal = isAutoRenewal;
	}
	
	/**
	*implementing autoRenewal method from Renewable Interface
	*method for checking auto renewal status
	*/
	@Override
	public void autoRenewal(int tenure) {
		
		if(isAutoRenewal == true) {
			
			if(tenure <12) {
				
				System.out.println("please auto renew before maturity date");
			}
			else {
			System.out.println("auto renewed ");
			}
		}
		System.out.println("autorenewel option is not selected");
			
			
		}
		
		
			
	
	/**
	*method for finding simple interest
	*/
	public void calculateSimpleInterest(InterestCalculator interestCalculator) {
			 
		this.simpleIntr = interestCalculator.calculateSimpleInterest(rate,additional);
		System.out.println("Interest in FD: "+simpleIntr);
		}
	
	/**
	*overriding method from Account class
	*method for finding interest
	*/
	@Override
	public void calculateInterest() {
		
		intr = (principal*rate*1)/100;
		System.out.println(" interest at FD :" +intr);
	}
		
		
	}
	
	
	 
	 
	 
	


