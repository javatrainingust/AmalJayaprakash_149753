package com.bankmanagement.model;

import static org.junit.Assert.*;

import org.junit.Test;

public class SBAccountTest {

	@Test
	public void testSBAccount() {
		
		float expected = 50;
		SBAccount sbAccount = new SBAccount();
		sbAccount.setPrincipal(1000);
		sbAccount.setRate(5);
		sbAccount.calculateInterest();
		float actual = sbAccount.getIntr();
		assertEquals(expected, actual, 0);
	}

}
