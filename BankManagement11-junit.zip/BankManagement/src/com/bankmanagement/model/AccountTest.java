package com.bankmanagement.model;

import static org.junit.Assert.*;

import org.junit.Test;

public class AccountTest {

	
	@Test
	public void testAccount() {
		
		float expected = 9000;
		Account account = new Account();
		account.setBalance(10000);
		float actual = account.withdrawMoney(1000);
		
		assertEquals(expected, actual, 0);
		
		
	}

}
