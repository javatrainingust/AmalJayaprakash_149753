package com.bankmanagement.service;

import com.bankmanagement.model.FDAccount;
import com.bankmanagement.model.SBAccount;

public class InterestService {
	
	public static void main (String args[]) {
		
		SBAccount sbAccount = new SBAccount();
		sbAccount.setAccountHolderName("jai");
		sbAccount.setAccountNumber(888);
		sbAccount.setPrincipal(1000);
		sbAccount.setRate(5);
		System.out.println("a/c holder :"+sbAccount.getAccountHolderName());
		System.out.println("a/c no :"+sbAccount.getAccountNumber());
		sbAccount.calculateInterest();
		
		System.out.println();
		
		FDAccount fdAccount = new FDAccount();
		fdAccount.setAccountHolderName("Rahul");
		fdAccount.setAccountNumber(477);
		fdAccount.setPrincipal(1000);
		fdAccount.setRate(7);
		System.out.println("a/c holder :"+fdAccount.getAccountHolderName());
		System.out.println("a/c no :"+fdAccount.getAccountNumber());
		fdAccount.calculateInterest();
	}

}
