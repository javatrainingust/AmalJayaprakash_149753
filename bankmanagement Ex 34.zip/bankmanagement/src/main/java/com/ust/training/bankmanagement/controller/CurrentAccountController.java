/**
 * Class name: CurrentAccountController
 * 
 * Desc: Controller class for Current Account
 *
 * Date : 15/10/2020
 * 
*/

package com.ust.training.bankmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ust.training.bankmanagement.model.CurrentAccount;
import com.ust.training.bankmanagement.service.CurrentAccountService;
/** for mapping current account operations */
@Controller
public class CurrentAccountController {
	/* autowiring current account service object */
	@Autowired
	CurrentAccountService caService;
	
	/* Creating new  current account  */
	@RequestMapping("/viewcurrentaccountform")
	public String viewCurrentAccountForm(Model model) {
		
		CurrentAccount ca = new CurrentAccount();
		model.addAttribute("currentaccounts2", ca);
		
		return "addCurrentAccount";
	}
	
	
	@RequestMapping("/addcurrentaccount")
	public String addCurrentAccount(@ModelAttribute("currentAccount") CurrentAccount ca) {
		
		caService.addCurrentAccount(ca);
		
		return "redirect:/allcurrentaccounts";
	}
	
	
	/* getting all current account details */
	@RequestMapping("/allcurrentaccounts")
	public String getAllCurrentAccounts(Model model) {
		
		List<CurrentAccount> current = caService.getAllCurrentAccounts();
		model.addAttribute("currentaccounts", current);
		
		return "currentAccount";
	}
	/* getting specific current account details */
	@RequestMapping("/viewcurrentaccount")
	public String getCurrentAccountByAccountNumber(@RequestParam("acno") int acno, Model model) {
		
		CurrentAccount ca = caService.getCurrentAccountByAccountNumber(acno);
		model.addAttribute("currentaccounts1", ca);
		
		return "viewCurrentAccount";
		
	}
	
	/* deleting specific current account details */
	@RequestMapping("/deletecurrentaccount")
	public String deleteCurrentAccountByAccountNumber(@RequestParam("acno") int acno) {
		
		caService.deleteCurrentAccount(acno);
	
		return "redirect:/allcurrentaccounts";
		
	}
	

}
