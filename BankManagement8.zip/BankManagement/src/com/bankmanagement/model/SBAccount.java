package com.bankmanagement.model;

import com.bankmanagement.util.InterestCalculator;

public class SBAccount extends Account{
	
	private double interest;
	private float rate;
	private float principal;
	
	

	 public float getPrincipal() {
		return principal;
	}




	public void setPrincipal(float principal) {
		this.principal = principal;
	}




	public double getInterest() {
		return interest;
	}




	public void setInterest(double interest) {
		this.interest = interest;
	}




	public double getRate() {
		return rate;
	}




	public void setRate(float rate) {
		this.rate = rate;
	}




	//overriding method from the Account
	
	@Override
	public void calculateInterest() {
		
		intr = (principal*rate*1)/100;
		System.out.println(" interest at SB:" +intr);
	}




	public void calculateSimpleInterest(InterestCalculator interestCalculator) {
		 
		 this.simpleIntr = interestCalculator.calculateSimpleInterest(rate);
		 System.out.println("Interest in SB: "+simpleIntr);	 }



}
