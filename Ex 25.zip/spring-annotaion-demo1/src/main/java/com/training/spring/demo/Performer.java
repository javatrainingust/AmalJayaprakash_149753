/**
 *Interface name: Performer
 * 
 * Desc: Interface for implementing in future classes
 * 
 * Date :13/10/2020
 * 
 */
package com.training.spring.demo;
/** interface declaring methods */
public interface Performer {
	
	public void perform();
}
