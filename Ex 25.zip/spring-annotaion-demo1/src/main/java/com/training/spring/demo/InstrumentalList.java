/**
 *Classs name: InstrumentalList
 * 
 * Desc: Implemented from Performer interface
 * 
 * Date :13/10/2020
 * 
 */
package com.training.spring.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/** bean class for Instrumental list with Component annotation*/
@Component("instrumentallist")
public class InstrumentalList implements Performer{
	
	/*auto wiring */
	@Autowired
	Saxophone saxophone;

	/* method implemented from Perform*/
	public void perform() {
		// TODO Auto-generated method stub
		saxophone.play();
	}

}
