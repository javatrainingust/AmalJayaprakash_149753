/**
 *Classs name: PerformanceDemo
 * 
 * Desc: main class
 * 
 * Date :13/10/2020
 * 
 */
package com.training.spring.demo;

import org.springframework.context.support.ClassPathXmlApplicationContext;
/* class for loading bean file and injecting value */
public class PerformanceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		/* getting Instrmental list object from spring container */
		InstrumentalList instrumentalList = context.getBean("instrumentallist", InstrumentalList.class);
		instrumentalList.perform();
		
	}

}
