/**
 *Classs name: Organizer
 * 
 * Desc: bean class for Organizer
 * 
 * Date :13/10/2020
 * 
 */
package com.training.spring.demo;

import org.springframework.stereotype.Component;
/** class modeling Organizer and is annotated with Component */
@Component("organizer")
public class Organizer {
	
	public void sayGreetings() {
		
		System.out.println("Welcome to the talent competion");
	}

}
