/**
 *Classs name: AboutMeController
 * 
 * Desc: Controller class
 * 
 * Date :14/10/2020
 * 
 */
package com.ust.training.springmvc;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
/** controller class for AbountMeController */
@Controller
public class AboutMeController {
	/* mapping method */
	@RequestMapping("/hobbies")
	public String getMyHobbies() {
		
		return "hobbies";
	}

}
