package com.bankmanagement.util;

/**...
 * InterestCalculatorImpl
 * implementing methods from InterestCalculator	
 * 30/09/2020
 * */

public class InterestCalculatorImpl implements InterestCalculator {
	
	private double principalAmount = 1000;
	private int period = 1;
	//private float rate;
	
	//for calculating SB Account simple  interest
	public float calculateSimpleInterest(double rate) {
		
		float simpleIntr = (float) (principalAmount*period*rate)/100;
		return simpleIntr;
	}
	
	//for calculating FD Account simple  interest
	//for FD account will get additional 10 as interest
	
	public float calculateSimpleInterest(double rate, float additional) {
		
	
		float simpleIntr = (float) (principalAmount*period*rate)/100 +additional;
		return simpleIntr;
	}
	
	

}
