package com.bankmanagement.model;
//child class of Account
public class CurrentAccount extends Account{
	
	private float overDraftlimit = 1000;
	
	//checking eligibility for overdrafting
	public void amountLimit(float balance) {
		
		if(balance < overDraftlimit) {
			
			System.out.println("you are eligible for overdrafting");
		}
		else {
			System.out.println("not eligible");
		}
	}

}
