package com.bankmanagement.model;

public class LoanAccount extends Account{
	
	private float EMI;
	private float loanOutStanding;
	
	private int tenture;
	public float getEMI() {
		return EMI;
	}
	public void setEMI(float eMI) {
		EMI = eMI;
	}
	public float getLoanOutStanding() {
		return loanOutStanding;
	}
	public void setLoanOutStanding(float loanOutStanding) {
		this.loanOutStanding = loanOutStanding;
	}
	public int getTenture() {
		return tenture;
	}
	public void setTenture(int tenture) {
		this.tenture = tenture;
	}
	//calculating emi
	public void calculateEMI() {
		
		EMI= loanOutStanding*3*tenture;
		System.out.println("EMI :"+EMI);
		
	}

}
