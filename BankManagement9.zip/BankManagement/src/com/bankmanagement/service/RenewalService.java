package com.bankmanagement.service;

import com.bankmanagement.model.FDAccount;
import com.bankmanagement.model.Renewable;

public class RenewalService {
	
	public static void main(String args[]) {
		FDAccount fdAccount = new FDAccount();
		fdAccount.setAccountHolderName("Roy");
		fdAccount.setAccountNumber(333);
	
		fdAccount.setAutoRenewal(true);
		//fdAccount.setAutoRenewal(false);
		
		Renewable renewable = new FDAccount();
		System.out.println("a/c holder :"+fdAccount.getAccountHolderName());
		System.out.println("a/c no :"+fdAccount.getAccountNumber());
		renewable.autoRenewal(12);
	}
}
