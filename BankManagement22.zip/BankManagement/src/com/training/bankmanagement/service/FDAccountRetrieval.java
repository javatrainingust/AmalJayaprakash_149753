package com.training.bankmanagement.service;

import com.training.bankmanagement.model.FDAccount;

public class FDAccountRetrieval {
	
	public static void main(String[] args) {
		
		FDAccountService fdAccountService = new FDAccountService();
		
		
		
		fdAccountService.addFDAccount(new FDAccount(100, "anu",5000));
		fdAccountService.addFDAccount(new FDAccount(101, "manu",2000));
		fdAccountService.addFDAccount(new FDAccount(102, "binu",3000));
		
		System.out.println("all fixed accounts");
		fdAccountService.getAllFDAAccounts();
		
		System.out.println();
		System.out.println("fixed account details");
		fdAccountService.getFDAAccountByAccountNumber(100);
		
		System.out.println();
		System.out.println("by a/c holder name");
		fdAccountService.getAllFDAccountsSortedByName();
		
		System.out.println();
		System.out.println("by balance");
		fdAccountService.getAllFDAccountsSortedByBalance();
		
	}
	
	
	

}
