package com.training.bankmanagement.service;

import com.training.bankmanagement.model.CurrentAccount;

public class CurrentAccountDelete {
	
public static void main(String[] args) {
		
		CurrentAccountService currentAccountService = new CurrentAccountService();
		currentAccountService.addCurrentAccount(new CurrentAccount(100, "anu",5000));
		currentAccountService.addCurrentAccount(new CurrentAccount(101, "manu",2000));
		currentAccountService.addCurrentAccount(new CurrentAccount(102, "binu",3000));
		System.out.println("all current accounts");
		currentAccountService.getAllCurrentAccounts();
		System.out.println();
		
		currentAccountService.deleteCurrentAccount(102);
		System.out.println("deleted");
		System.out.println("after deletion");
		currentAccountService.getAllCurrentAccounts();
		
	}

}
