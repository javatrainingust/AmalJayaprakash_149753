package com.training.bankmanagement.service;

import com.training.bankmanagement.model.SBAccount;

public class SBAccountSort {
	
	public static void main(String args[]) {
		
		SBAccountService sbAccountService = new SBAccountService();
		sbAccountService.addSBAccount(new SBAccount(100, "anu",5000));
		sbAccountService.addSBAccount(new SBAccount(101, "manu",2000));
		sbAccountService.addSBAccount(new SBAccount(102, "binu",3000));
		
		System.out.println("All SB accounts");
		sbAccountService.getAllSBAccounts();
		
		System.out.println();
		
		System.out.println("SB accounts sorted by a/c holder name");
		sbAccountService.getAllSBAccountsSortedByName();
		
		System.out.println();
		
		System.out.println("SB accounts sorted by balance");
		sbAccountService.getAllSBAccountsSortedByBalance();
	}
 
}
