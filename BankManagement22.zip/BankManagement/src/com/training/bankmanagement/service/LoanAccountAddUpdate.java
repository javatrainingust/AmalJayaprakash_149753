package com.training.bankmanagement.service;

import com.training.bankmanagement.model.LoanAccount;

public class LoanAccountAddUpdate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LoanAccountService loanAccountService = new LoanAccountService();
		loanAccountService.addLoanAccount(new LoanAccount(100, "anu",1200));
		loanAccountService.addLoanAccount(new LoanAccount(101, "manu",400));
		loanAccountService.addLoanAccount(new LoanAccount(102, "vinu",600));
		System.out.println("before update");
		loanAccountService.getAllLoanAccounts();
		loanAccountService.updateLoanAccount(new LoanAccount(102, "vinu",700));
		System.out.println("after update");
		loanAccountService.getAllLoanAccounts();

	}

}
