/**
 * Classname:CurrentAccountService
 * 
 * Description:This class forms sevices from data access class 
 *
 * Date:06/10/2020
 * 
*/
package com.training.bankmanagement.service;


import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import com.training.bankmanagement.dao.CurrentAccountDAO;
import com.training.bankmanagement.dao.CurrentAccountDAOImpl;
import com.training.bankmanagement.model.CurrentAccount;


/**
*This is a class used for add,delete,get the current account detalis using data access class object.
*/
public class CurrentAccountService {
	
	CurrentAccountDAO currentAccountDAO;
	
	 public CurrentAccountService() {
			
		currentAccountDAO = new CurrentAccountDAOImpl();
		}
		/**
		*method for getting all current accounts using data access class object
		*
		*/
		public List<CurrentAccount> getAllCurrentAccounts() {
			
			List<CurrentAccount> currentAccountList = currentAccountDAO.getAllCurrentAccounts();
			
			Iterator<CurrentAccount> iterator = currentAccountList.iterator();
			
			while(iterator.hasNext()) {
				
				CurrentAccount ca = iterator.next();
				System.out.println("A/c no: "+ca.getAccountNumber());
				System.out.println("A/c holder name: "+ca.getAccountHolderName());
				System.out.println("Over draft limit: "+ca.getOverDraftlimit());
			}
			return currentAccountList;
		}
		/**
		*method for getting current account details by account number using data access class object
		*
		*/
		public CurrentAccount getCurrentAccountByAccountNumber(int accountNumber) {
			
			CurrentAccount ca = currentAccountDAO.getCurrentAccountByAccountNumber(accountNumber);
			System.out.println("A/c no: "+ca.getAccountNumber());
			System.out.println("A/c holder name: "+ca.getAccountHolderName());
			System.out.println("Over draft limit: "+ca.getOverDraftlimit());
			
			return ca;
		}
		/**
		*method for deleting current account by account number using data access class object
		*
		*/
		public void deleteCurrentAccount(int accountNumber) {
			currentAccountDAO.deleteCurrentAccount(accountNumber);
		}
		
		/**
		*method for sorting current account by a/c holder name
		*
		*/
		public List<CurrentAccount> getAllCurrentAccountsSortedByName() {
			
			List<CurrentAccount> currentList = currentAccountDAO.getAllCurrentAccounts();
			//Collections.sort(currentSortedList);
			/*using streams*/
			List<CurrentAccount> currentSortedList = currentList.stream().sorted().collect(Collectors.toList());
			
			Iterator<CurrentAccount> iterator = currentSortedList.iterator();
			while(iterator.hasNext()) {
				
				CurrentAccount ca = iterator.next();
				System.out.println("A/c no: "+ca.getAccountNumber());
				System.out.println("A/c holder name: "+ca.getAccountHolderName());
				System.out.println("over draft limit: "+ca.getOverDraftlimit());
			}
			return currentSortedList;
			
			
		}
		
		/**
		*method for sorting current account by over draft limit
		*
		*/
		public List<CurrentAccount> getAllCurrentAccountsSortedByOverdraftLimit() {
			
			List<CurrentAccount> currentList = currentAccountDAO.getAllCurrentAccounts();
			//Collections.sort(currentSortedList, new CurrentAccountComparator());
			/*using streams*/
			List<CurrentAccount> currentSortedList = currentList.stream().sorted(new CurrentAccountComparator()).collect(Collectors.toList());
			Iterator<CurrentAccount> iterator = currentSortedList.iterator();
			while(iterator.hasNext()) {
				
				CurrentAccount ca = iterator.next();
				System.out.println("A/c no: "+ca.getAccountNumber());
				System.out.println("A/c holder name: "+ca.getAccountHolderName());
				System.out.println("over draft limit: "+ca.getOverDraftlimit());
			}
			return currentSortedList;
			
			
		}
		
		/**
		*method for adding current account 
		*
		*/
		public void addCurrentAccount(CurrentAccount currentAccount) {
			
			boolean isAdded = currentAccountDAO.addCurrentAccount(currentAccount);
			if(!isAdded) {
				System.out.println("this account alredy exist");
			}
			else {
				System.out.println("account added");
			}
		}
		
		/**
		*method for current loan account 
		*
		*/
		public void updateCurrentAccount(CurrentAccount currentAccount) {
			
			currentAccountDAO.updateCurrentAccount(currentAccount);
			System.out.println("updated");
		}
			
			
		
		

}
