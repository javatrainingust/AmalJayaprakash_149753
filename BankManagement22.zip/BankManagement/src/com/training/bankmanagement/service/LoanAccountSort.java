package com.training.bankmanagement.service;

import com.training.bankmanagement.model.LoanAccount;

public class LoanAccountSort {
	
	public static void main(String args[]) {
		
		LoanAccountService loanAccountService = new LoanAccountService();
		loanAccountService.addLoanAccount(new LoanAccount(100, "anu",5000));
		loanAccountService.addLoanAccount(new LoanAccount(101, "manu",2000));
		loanAccountService.addLoanAccount(new LoanAccount(102, "binu",3000));
		
		System.out.println("All loan accounts");
		loanAccountService.getAllLoanAccounts();
		
		System.out.println();
		
		System.out.println("loan accounts sorted by a/c holder name");
		loanAccountService.getAllLoanAccountsSortedByName();
		
		System.out.println();
		
		System.out.println("Loan accounts sorted by loan out standing");
		loanAccountService.getAllLoanAccountsSortedByLoanOutstanding();
	}

}
