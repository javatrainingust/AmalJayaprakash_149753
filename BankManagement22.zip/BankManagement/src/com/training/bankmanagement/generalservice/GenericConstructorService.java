package com.training.bankmanagement.generalservice;

import com.training.bankmanagement.model.SBAccount;
/**...
 * GenericConstructorService
 * for finding simple interest of SB by invoking constructor
 * 30/09/2020
 * */
public class GenericConstructorService {
	
	public static void main(String args[]) {
		
		SBAccount sbAccount = new SBAccount(100,"anu",5,1000);
		System.out.println("a/c holder :"+sbAccount.getAccountHolderName());
		System.out.println("a/c no :"+sbAccount.getAccountNumber());
		sbAccount.calculateInterest();
	}

}
