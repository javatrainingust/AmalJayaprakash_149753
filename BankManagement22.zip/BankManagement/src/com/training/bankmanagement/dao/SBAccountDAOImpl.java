/**
 * Classname:SBAccountDAOImpl
 * 
 * Description:This class is implemented from SBAccountDAO for data access operations
 *
 * Date:06/10/2020
 * 
*/
package com.training.bankmanagement.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.training.bankmanagement.model.SBAccount;
/**
*This is a class used for add,delete,get the Savings account detalis.
*/
public class SBAccountDAOImpl implements SBAccountDAO{
	
	List<SBAccount> sbAccountList;
	private Set<SBAccount> sbAccountSet;
	/**
	*constructor for SBAccountDAOImpl
	*/
	public SBAccountDAOImpl() {
		 
		sbAccountList = new ArrayList<SBAccount>();
		sbAccountSet = new HashSet<SBAccount>();
//		sbAccountList.add(new SBAccount(100, "anu",15000));
//		sbAccountList.add(new SBAccount(101, "manu",22000));
//		sbAccountList.add(new SBAccount(102, "vinu",3000));
		
	}
	/**
	*method for getting all savings accounts
	*method implemented from SBAccountDAO
	*/
	@Override
	public List<SBAccount> getAllSBAccounts() {
		// TODO Auto-generated method stub
		return sbAccountList;
	}
	/**
	*method for getting savings account details by account number
	*method implemented from SBAccountDAO
	*/
	@Override
	public SBAccount getSBAccountByAccountNumber(int accountNumber) {
		// TODO Auto-generated method stub
		SBAccount sbAccount = null;
		Iterator<SBAccount> iterator = sbAccountList.iterator();
		while(iterator.hasNext()) {
			
			SBAccount sb = iterator.next();
			
			if(sb.getAccountNumber() == accountNumber) {
				
				sbAccount = sb;
			}
		}
		return sbAccount;
	}
	/**
	*method for deleting savings  account by account number
	*method implemented from SBAccountDAO
	*/
	@Override
	public void deleteSBAccount(int accountNumber) {
		// TODO Auto-generated method stub
			for(int i = 0; i < sbAccountList.size(); i++) {
			
				SBAccount sb = sbAccountList.get(i);
				if(sb.getAccountNumber() == accountNumber) {
				
					sbAccountList.remove(i);
			}
		}
		
	}
	
	/**
	*method for adding savings account 
	*method implemented from SBAccountDAO
	*/
	@Override
	public boolean addSBAccount(SBAccount sbAccount) {
		// TODO Auto-generated method stub
		boolean isAdded = sbAccountSet.add(sbAccount);
		if(isAdded) {
			sbAccountList.add(sbAccount);
		}
		return isAdded;
	}
	
	/**
	*method for updating savings account 
	*method implemented from SBAccountDAO
	*/
	@Override
	public void updateSBAccount(SBAccount sbAccount) {
		// TODO Auto-generated method stub
		Iterator<SBAccount> iterator = sbAccountList.iterator();
		while(iterator.hasNext()) {
			SBAccount sb = iterator.next();
			
			if(sb.getAccountNumber() == sbAccount.getAccountNumber()) {
				
				sb.setAccountHolderName(sbAccount.getAccountHolderName());
				sb.setBalance(sbAccount.getBalance());
			}
			
		}
	}

}
