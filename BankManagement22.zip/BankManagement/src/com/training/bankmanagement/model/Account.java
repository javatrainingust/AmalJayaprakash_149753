/**
 * Classname:Account
 * 
 * Description:This is a base class for Account sub types
 *
 * Date:30/09/2020
 * 
*/

package com.training.bankmanagement.model;

/**
*This is a class used to model Account details of Account holder.
*/
public class Account {
	
	private int accountNumber;
	private String accountHolderName;
	private float balance;
	protected float intr;
	protected float simpleIntr;
	
	
	
	

	/**
	*no arg constructor for Account
	*/
	public Account() {
		
	}
	
	/**
	*param  constructor for Account
	*/
	public Account(int accountNumber, String accountHolderName) {
		
		this.accountNumber = accountNumber; 
		this.accountHolderName = accountHolderName;
		
	}
	
	public Account(int accountNumber, String accountHolderName, float balance) {
		
		this.accountNumber = accountNumber;
		this.accountHolderName = accountHolderName;
		this.balance = balance;
		
	}
	

	
	
	public int getAccountNumber() {
		return accountNumber;
	}







	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}



	public String getAccountHolderName() {
		return accountHolderName;
	}



	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}



	public float getBalance() {
		return balance;
	}



	public void setBalance(float balance) {
		this.balance = balance;
	}



	public float getIntr() {
		return intr;
	}



	public void setIntr(float intr) {
		this.intr = intr;
	}
	
	public float getSimpleIntr() {
		return simpleIntr;
	}

	public void setSimpleIntr(float simpleIntr) {
		this.simpleIntr = simpleIntr;
	}
	
	

	/**
	*hashcode and equal methods
	*/
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountNumber;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		if (accountNumber != other.accountNumber)
			return false;
		return true;
	}

	/**
	*method for calculating balance after withdrawl
	*/
	public float withdrawMoney(int amountToWithdraw) {
		
		return this.balance = this.balance - amountToWithdraw;
		
	}
	
	/**
	*method for calculating interest
	*overridden method
	*/
	public void calculateInterest() {
		
		System.out.println("calculating interest");
	}
	

}
