package com.training.bankmanagement.test;

import static org.junit.Assert.*;
import org.junit.Test;

import com.training.bankmanagement.dao.SBAccountDAOImpl;
import com.training.bankmanagement.model.FDAccount;
import com.training.bankmanagement.model.SBAccount;
import com.training.bankmanagement.service.SBAccountService;

public class SBAccountServiceTest {
	
	SBAccountService sbAccountService;
	  
	  public SBAccountServiceTest() {
	  
		  sbAccountService = new SBAccountService();
		  sbAccountService.addSBAccount(new SBAccount(100,"anu",5000));
		  sbAccountService.addSBAccount(new SBAccount(101,"manu",2000));
		  sbAccountService.addSBAccount(new SBAccount(102,"vinu",3000));
	  }
	  
	  @Test
	  public void testAddSBAccountSuccess() {
		  sbAccountService.addSBAccount(new SBAccount(103,"roy",6000));
			int actual = sbAccountService.getAllSBAccounts().size();
			int expected = 4;
			assertEquals(expected, actual); 
			
		}
		
	  @Test
	  public void testAddSBAccountFailure() {
		  	sbAccountService.addSBAccount(new SBAccount(102,"ginu",3000));
			String actual = sbAccountService.getSBAccountByAccountNumber(102).getAccountHolderName();
			System.out.println(actual);
			String expected = "vinu";
			assertEquals(expected, actual); 
			
		}
		
	  @Test 
	  public void testGetAllSBAccounts() { 

		  int actual = sbAccountService.getAllSBAccounts().size(); 
		  int expected = 3;
		  assertEquals(expected, actual); 
		  
	  }
	  
	  @Test 
	  public void testGetSBAccountByAccountNumber() { 
		  
		  String actual = sbAccountService.getSBAccountByAccountNumber(100).getAccountHolderName();
		  String expected = "anu";
		  assertEquals(expected, actual); 
		  
	  }
	  
	  
	  @Test 
	  public void testDeleteSBAccount() { 
		  
		  SBAccountDAOImpl sbAccountDAOImpl = new SBAccountDAOImpl();
		  sbAccountDAOImpl.deleteSBAccount(102);
		  SBAccount actual = sbAccountDAOImpl.getSBAccountByAccountNumber(102);
		  System.out.println(actual);
		  FDAccount expected = null; 
		  assertEquals(expected,actual); 
		  
	  }
	  
	  @Test 
	  public void testGetAllSBAccountsSortByName() { 
		  String actual = sbAccountService.getAllSBAccountsSortedByName().get(0).getAccountHolderName();
		  String expected = "anu"; 
		  assertEquals(expected, actual); 
		  
	  }
	  
	  @Test 
	  public void testGetAllSBAccountsSortByBalance() { 
		  
		  String actual = sbAccountService.getAllSBAccountsSortedByBalance().get(0).getAccountHolderName(); 
		  System.out.println(actual); 
		  String expected = "manu";
		  assertEquals(expected, actual); 
		  
	  }
	 
	 
	  @Test
	  public void testUpdateSBAccount() {
		  
		sbAccountService.updateSBAccount(new SBAccount(102,"vinu",3500));
		float actual = sbAccountService.getSBAccountByAccountNumber(102).getBalance();
		System.out.println(actual);
		float expected = 3500;
		assertEquals(expected, actual,0);
		
	}
	



}
