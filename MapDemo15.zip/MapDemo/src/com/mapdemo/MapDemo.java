package com.mapdemo;

import java.util.HashMap;
import java.util.Map;



public class MapDemo {
	
	public static void main(String args[]) {
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("srk", "fan");
		map.put("vijay", "mersal");
		map.put("fahad", "c u soon");
		
		System.out.println("srk movie :" +map.get("srk"));
		System.out.println("vijay movie :" +map.get("vijay"));
		System.out.println("fahad movie :" +map.get("fahad"));
		
		System.out.println();
		
		Cat cat1 = new Cat("rosy", 2);
		Cat cat2 = new Cat("pinky", 3);
		Cat cat3 = new Cat("mikky", 4);
		
		Map<Cat, String> cats = new HashMap<Cat, String>();
		cats.put(cat1, "roy");
		cats.put(cat2, "jinu");
		cats.put(cat3, "anu");
		
		System.out.println("rosy's pet parent' :"+cats.get(cat1));
		System.out.println("pinky's pet parent :"+cats.get(cat2));
		System.out.println("mikky's pet parent :"+cats.get(cat3));
		
	
		
	}

}
