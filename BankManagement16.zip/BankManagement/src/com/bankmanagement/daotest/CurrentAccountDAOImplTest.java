package com.bankmanagement.daotest;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.bankmanagement.dao.CurrentAccountDAOImpl;
import com.bankmanagement.model.CurrentAccount;


public class CurrentAccountDAOImplTest {

List<CurrentAccount> currentList;
	
    public CurrentAccountDAOImplTest() {
	
    	currentList = new ArrayList<CurrentAccount>();
    	currentList.add(new CurrentAccount(100,"anu"));
    	currentList.add(new CurrentAccount(101,"manu"));
    	currentList.add(new CurrentAccount(102,"vinu"));
}
	

	@Test
	public void testGetAllCurrentAccounts() {
		CurrentAccountDAOImpl currentAccountDAOImpl = new CurrentAccountDAOImpl();
		int actual = currentAccountDAOImpl.getAllCurrentAccounts().size();
		int expected = currentList.size();
		assertEquals(expected, actual);
	}
	
	@Test
	public void testGetCurrentAccountByAccountNumber() {
		CurrentAccountDAOImpl currentAccountDAOImpl = new CurrentAccountDAOImpl();
		String actual = currentAccountDAOImpl.getCurrentAccountByAccountNumber(100).getAccountHolderName();
		String expected = currentList.get(0).getAccountHolderName();
		assertEquals(expected, actual);
	}
	
	@Test
	public void testDeleteCurrentAccount() {
		CurrentAccountDAOImpl currentAccountDAOImpl = new CurrentAccountDAOImpl();
		currentAccountDAOImpl.deleteCurrentAccount(102);;
		CurrentAccount actual = currentAccountDAOImpl.getCurrentAccountByAccountNumber(102);
		System.out.println(actual); 
		CurrentAccount expected = null;
		assertEquals(expected, actual);
	}


}
