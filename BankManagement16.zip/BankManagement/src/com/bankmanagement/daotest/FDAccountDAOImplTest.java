package com.bankmanagement.daotest;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.bankmanagement.dao.FDAccountDAOImpl;
//import com.bankmanagement.dao.FDAccountDAOImpl;
import com.bankmanagement.model.FDAccount;

public class FDAccountDAOImplTest {
	
	List<FDAccount> fdList;
	
    public FDAccountDAOImplTest() {
	
    	fdList = new ArrayList<FDAccount>();
    	fdList.add(new FDAccount(100,"anu"));
    	fdList.add(new FDAccount(101,"manu"));
    	fdList.add(new FDAccount(102,"vinu"));
}
	

	@Test
	public void testGetAllFDAccounts() {
		FDAccountDAOImpl fdAccountDAOImpl = new FDAccountDAOImpl();
		int actual = fdAccountDAOImpl.getAllFDAAccounts().size();
		int expected = fdList.size();
		assertEquals(expected, actual);
	}
	
	@Test
	public void testGetFDAccountByAccountNumber() {
		FDAccountDAOImpl fdAccountDAOImpl = new FDAccountDAOImpl();
		String actual = fdAccountDAOImpl.getFDAAccountByAccountNumber(100).getAccountHolderName();
		String expected = fdList.get(0).getAccountHolderName();
		assertEquals(expected, actual);
	}
	
	@Test
	public void testDeleteFDAccount() {
		FDAccountDAOImpl fdAccountDAOImpl = new FDAccountDAOImpl();
		fdAccountDAOImpl.deleteFDAAccount(102);;
		FDAccount actual = fdAccountDAOImpl.getFDAAccountByAccountNumber(102);
		System.out.println(actual); 
		FDAccount expected = null;
		assertEquals(expected, actual);
	}

}
