package com.bankmanagement.daotest;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;


import com.bankmanagement.dao.SBAccountDAOImpl;
import com.bankmanagement.model.FDAccount;
import com.bankmanagement.model.SBAccount;

public class SBAccountDAOImplTest {

List<SBAccount> sbList;
	
    public SBAccountDAOImplTest() {
	
    	sbList = new ArrayList<SBAccount>();
    	sbList.add(new SBAccount(100,"anu"));
    	sbList.add(new SBAccount(101,"manu"));
    	sbList.add(new SBAccount(102,"vinu"));
}
	

	@Test
	public void testGetAllSBAccounts() {
		SBAccountDAOImpl sbAccountDAOImpl = new SBAccountDAOImpl();
		int actual = sbAccountDAOImpl.getAllSBAccounts().size();
		int expected = sbList.size();
		assertEquals(expected, actual);
	}
	
	@Test
	public void testGetSBAccountByAccountNumber() {
		SBAccountDAOImpl sbAccountDAOImpl = new SBAccountDAOImpl();
		String actual = sbAccountDAOImpl.getSBAccountByAccountNumber(100).getAccountHolderName();
		String expected = sbList.get(0).getAccountHolderName();
		assertEquals(expected, actual);
	}
	
	@Test
	public void testDeleteSBAccount() {
		SBAccountDAOImpl sbAccountDAOImpl = new SBAccountDAOImpl();
		sbAccountDAOImpl.deleteSBAccount(102);;
		SBAccount actual = sbAccountDAOImpl.getSBAccountByAccountNumber(102);
		System.out.println(actual); 
		FDAccount expected = null;
		assertEquals(expected, actual);
	}

}
