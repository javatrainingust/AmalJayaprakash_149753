package com.bankmanagement.service;

import com.bankmanagement.model.Account;
import com.bankmanagement.model.CurrentAccount;
import com.bankmanagement.model.FDAccount;
import com.bankmanagement.model.LoanAccount;
import com.bankmanagement.model.SBAccount;

public class AccountService {
	
	public static void main(String args[]) {
		
		Account account = new Account();
		account.setAccountNumber(100);
		account.setAccountHolderName("amal");
		account.setBalance(10000);
		account.withdrawMoney(1000);
		System.out.println("a/c holder :"+account.getAccountHolderName());
		System.out.println("a/c no :"+account.getAccountNumber());
		System.out.println("Balance :"+account.getBalance());
		System.out.println();
		
		CurrentAccount currentAccount = new CurrentAccount();
		currentAccount.setAccountHolderName("rahul");
		currentAccount.setAccountNumber(565);
		System.out.println("a/c holder :"+currentAccount.getAccountHolderName());
		System.out.println("a/c no :"+currentAccount.getAccountNumber());
		currentAccount.amountLimit(900);
		System.out.println();
		
		FDAccount fdAccount = new FDAccount();
		fdAccount.setAccountHolderName("arun");
		fdAccount.setAccountNumber(654);
		fdAccount.setAutoRenewal(true);
		//fdAccount.setAutoRenewal(false);
		//fdAccount.setTenure(12);
		System.out.println("a/c holder :"+fdAccount.getAccountHolderName());
		System.out.println("a/c no :"+fdAccount.getAccountNumber());
		//fdAccount.autorenew();
		System.out.println();
		
		FDAccount fdAccount1 = new FDAccount();
		fdAccount1.setAccountHolderName("Raj");
		fdAccount1.setAccountNumber(114);
		//fdAccount1.setAutoRenewal(true);
		fdAccount.setAutoRenewal(false);
		//fdAccount1.setTenure(5);
		System.out.println("a/c holder :"+fdAccount1.getAccountHolderName());
		System.out.println("a/c no :"+fdAccount1.getAccountNumber());
		//fdAccount.autorenew();
		fdAccount.setRate(10);
		fdAccount.calculateInterest();
		System.out.println();
		
		
		
		LoanAccount loanAccount = new LoanAccount();
		loanAccount.setAccountHolderName("adi");
		loanAccount.setAccountNumber(203);
		System.out.println("a/c holder :"+loanAccount.getAccountHolderName());
		System.out.println("a/c no :"+loanAccount.getAccountNumber());
		loanAccount.setLoanOutStanding(1000);
		loanAccount.setTenture(10);
		loanAccount.calculateEMI();
		System.out.println();
		
		SBAccount sbAccount = new SBAccount();
		sbAccount.setAccountHolderName("anu");
		sbAccount.setAccountNumber(100);
		sbAccount.setInterest(3.5);
		System.out.println("Accnt holder:"+sbAccount.getAccountHolderName());
		System.out.println("you interest :" +sbAccount.getInterest());
		sbAccount.setRate(5);
		//sbAccount.calculateInterest();
		
	}

}
