package com.bankmanagement.daoservice;

public class CurrentAccountRetrieval {
	
public static void main(String[] args) {
		
		CurrentAccountService currentAccountService = new CurrentAccountService();
		System.out.println("all current accounts");
		currentAccountService.getAllCurrentAccounts();
		System.out.println();
		System.out.println("current account details");
		currentAccountService.getCurrentAccountByAccountNumber(102);
		
	}

}
