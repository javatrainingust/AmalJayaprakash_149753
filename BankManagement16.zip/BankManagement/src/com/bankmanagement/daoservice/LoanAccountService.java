/**
 * Classname:LoanAccountService
 * 
 * Description:This class forms sevices from data access class 
 *
 * Date:06/10/2020
 * 
*/
package com.bankmanagement.daoservice;

import java.util.Iterator;
import java.util.List;
import com.bankmanagement.dao.LoanAccountDAO;
import com.bankmanagement.dao.LoanAccountDAOImpl;
import com.bankmanagement.model.LoanAccount;

/**
*This is a class used for add,delete,get the loan account detalis using data access class object.
*/
public class LoanAccountService {

	
	LoanAccountDAO loanAccountDAO;
	
	public LoanAccountService() {
			
		loanAccountDAO = new LoanAccountDAOImpl();
		}
		/**
		*method for getting all loan accounts using data access class object
		*
		*/
		public List<LoanAccount> getAllLoanAccounts() {
			
			List<LoanAccount> loanAccountList = loanAccountDAO.getAllLoanAccounts();
			
			Iterator<LoanAccount> iterator = loanAccountList.iterator();
			
			while(iterator.hasNext()) {
				
				LoanAccount la = iterator.next();
				System.out.println("A/c no: "+la.getAccountNumber());
				System.out.println("A/c holder name: "+la.getAccountHolderName());
				//System.out.println("A/c balance: "+fd.getBalance());
			}
			return loanAccountList;
		}
		/**
		*method for getting loan account details by account number using data access class object
		*
		*/
		public LoanAccount getLoanAccountByAccountNumber(int accountNumber) {
			
			LoanAccount la = loanAccountDAO.getLoanAccountByAccountNumber(accountNumber);
			System.out.println("A/c no: "+la.getAccountNumber());
			System.out.println("A/c holder name: "+la.getAccountHolderName());
			//System.out.println("A/c balance: "+fd.getBalance());
			
			return la;
		}
		/**
		*method for deleting loan account by account number using data access class object
		*
		*/
		public void deleteLoanAccount(int accountNumber) {
			loanAccountDAO.deleteLoanAccount(accountNumber);
		}
		


}
