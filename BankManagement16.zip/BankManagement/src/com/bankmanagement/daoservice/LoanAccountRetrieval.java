package com.bankmanagement.daoservice;

public class LoanAccountRetrieval {
	
public static void main(String[] args) {
		
		LoanAccountService loanAccountService = new LoanAccountService();
		System.out.println("all loan accounts");
		loanAccountService.getAllLoanAccounts();
		System.out.println();
		System.out.println("loan account details");
		loanAccountService.getLoanAccountByAccountNumber(100);
		
	}

}
