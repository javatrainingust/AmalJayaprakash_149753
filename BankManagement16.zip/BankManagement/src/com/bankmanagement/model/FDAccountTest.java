package com.bankmanagement.model;

import static org.junit.Assert.*;

import org.junit.Test;

public class FDAccountTest {

	@Test
	public void testFDAccount() {
		float expected = 70;
		FDAccount fdAccount = new FDAccount();
		fdAccount.setPrincipal(1000);
		fdAccount.setRate(7);
		fdAccount.calculateInterest();
		float actual = fdAccount.getIntr();
		
		assertEquals(expected, actual, 0);
	}

}
