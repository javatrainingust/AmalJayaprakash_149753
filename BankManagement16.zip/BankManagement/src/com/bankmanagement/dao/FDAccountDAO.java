/**
 * Interface name:FDAccountDAO
 * 
 * Description:This interface is form data access operations
 *
 * Date:06/10/2020
 * 
*/
package com.bankmanagement.dao;

import java.util.List;

import com.bankmanagement.model.FDAccount;
/**
*This interface declare data access operations.
*/
public interface FDAccountDAO {
	
	public List<FDAccount> getAllFDAAccounts();
	public FDAccount getFDAAccountByAccountNumber(int accountNumber);
	public void deleteFDAAccount(int accountNumber);

}
