/**
 * Classname:FDAccountDAOImpl
 * 
 * Description:This class is implemented from FDAccountDAO for data access operations
 *
 * Date:06/10/2020
 * 
*/
package com.bankmanagement.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.bankmanagement.model.FDAccount;
/**
*This is a class used for add,delete,get the fixed account detalis.
*/
public class FDAccountDAOImpl implements FDAccountDAO {
	
	List<FDAccount> fdAccountList;
	/**
	*constructor for FDAccountDAOImpl
	*/
	public FDAccountDAOImpl() {
		
		fdAccountList = new ArrayList<FDAccount>();
		
		fdAccountList.add(new FDAccount(100, "anu"));
		fdAccountList.add(new FDAccount(101, "manu"));
		fdAccountList.add(new FDAccount(102, "vinu"));
		
	}
	/**
	*method for getting all fixed accounts
	*method implemented from FDAAccountDAO
	*/
	@Override
	public List<FDAccount> getAllFDAAccounts() {
		// TODO Auto-generated method stub
		return fdAccountList;
	}
	/**
	*method for getting fixed account details by account number
	*method implemented from FDAAccountDAO
	*/
	@Override
	public FDAccount getFDAAccountByAccountNumber(int accountNumber) {
		// TODO Auto-generated method stub
		FDAccount fdAccount = null;
		Iterator<FDAccount> iterator = fdAccountList.iterator();
		while(iterator.hasNext()) {
			
			FDAccount fd = iterator.next();
			
			if(fd.getAccountNumber() == accountNumber) {
				
				fdAccount = fd;
			}
		}
		return fdAccount;
	}
	/**
	*method for deleting fixed account by account number
	*method implemented from FDAAccountDAO
	*/
	@Override
	public void deleteFDAAccount(int accountNumber) {
		// TODO Auto-generated method stub
		for(int i = 0; i < fdAccountList.size(); i++) {
			
			FDAccount fd = fdAccountList.get(i);
			if(fd.getAccountNumber() == accountNumber) {
				
				fdAccountList.remove(i);
			}
		}
	}
	

}
