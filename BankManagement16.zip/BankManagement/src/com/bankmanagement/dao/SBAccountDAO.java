/**
 * Interface name:SBAccountDAO
 * 
 * Description:This interface is form data access operations
 *
 * Date:06/10/2020
 * 
*/
package com.bankmanagement.dao;

import java.util.List;


import com.bankmanagement.model.SBAccount;
/**
*This interface declare data access operations.
*/
public interface SBAccountDAO {
	
	public List<SBAccount> getAllSBAccounts();
	public SBAccount getSBAccountByAccountNumber(int accountNumber);
	public void deleteSBAccount(int accountNumber);

}
