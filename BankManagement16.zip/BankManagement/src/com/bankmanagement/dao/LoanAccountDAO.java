/**
 * Interface name:LoanAccountDAO
 * 
 * Description:This interface is form data access operations
 *
 * Date:06/10/2020
 * 
*/
package com.bankmanagement.dao;

import java.util.List;
import com.bankmanagement.model.LoanAccount;

public interface LoanAccountDAO {
	
	public List<LoanAccount> getAllLoanAccounts();
	public LoanAccount getLoanAccountByAccountNumber(int accountNumber);
	public void deleteLoanAccount(int accountNumber);

}
