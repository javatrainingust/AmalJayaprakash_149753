/**
 * Classname:LoanAccountDAOImpl
 * 
 * Description:This class is implemented from LoanAccountDAO for data access operations
 *
 * Date:06/10/2020
 * 
*/
package com.bankmanagement.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import com.bankmanagement.model.LoanAccount;

/**
*This is a class used for add,delete,get the loan account detalis.
*/
public class LoanAccountDAOImpl implements LoanAccountDAO{
	
	List<LoanAccount> loanAccountList;
	/**
	*constructor for LoanAccountDAOImpl
	*/
	public LoanAccountDAOImpl() {
		
		loanAccountList = new ArrayList<LoanAccount>();
		
		loanAccountList.add(new LoanAccount(100, "anu"));
		loanAccountList.add(new LoanAccount(101, "manu"));
		loanAccountList.add(new LoanAccount(102, "vinu"));
		
	}
	/**
	*method for getting all loan accounts
	*method implemented from LoanAccountDAO
	*/
	@Override
	public List<LoanAccount> getAllLoanAccounts() {
		// TODO Auto-generated method stub
		return loanAccountList;
	}
	/**
	*method for getting loan account details by account number
	*method implemented from LoanAccountDAO
	*/
	@Override
	public LoanAccount getLoanAccountByAccountNumber(int accountNumber) {
		// TODO Auto-generated method stub
		LoanAccount loanAccount = null;
		Iterator<LoanAccount> iterator = loanAccountList.iterator();
		while(iterator.hasNext()) {
			
			LoanAccount la = iterator.next();
			
			if(la.getAccountNumber() == accountNumber) {
				
				loanAccount = la;
			}
		}
		return loanAccount;
	}
	/**
	*method for deleting loan  account by account number
	*method implemented from LoanAccountDAO
	*/
	@Override
	public void deleteLoanAccount(int accountNumber) {
		// TODO Auto-generated method stub
		for(int i = 0; i < loanAccountList.size(); i++) {
			
			LoanAccount la = loanAccountList.get(i);
			if(la.getAccountNumber() == accountNumber) {
				
				loanAccountList.remove(i);
			}
		}
		
	}

}
