/**
 *Classs name: AboutMeController
 * 
 * Desc: Controller class
 * 
 * Date :14/10/2020
 * 
 */
package com.ust.training.springmvc;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/** controller class for AbountMeController */
@Controller
public class AboutMeController {
	
	/* mapping method */
	@RequestMapping("/hobbies")
	public String getMyHobbies() {
		
		return "aboutMe";
	}
	
	
	@RequestMapping("/processForm")
	public String process(@RequestParam("hobby") String myHobby, Model model) {
		
		String processedHobbies = " my hobby is " +myHobby;
		
		model.addAttribute("hobby1", processedHobbies);
		
		return "myHobbies";
	}

}
