package com.ust.training.bankmanagement.service;

import com.ust.training.bankmanagement.model.FDAccount;

public class FDAccountAddUpdate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FDAccountService fdAccountService = new FDAccountService();
		fdAccountService.addFDAccount(new FDAccount(100, "anu",5000));
		fdAccountService.addFDAccount(new FDAccount(101, "manu",2000));
		fdAccountService.addFDAccount(new FDAccount(102, "vinu",3000));
		System.out.println("before update");
		fdAccountService.getAllFDAAccounts();
		fdAccountService.updateFDAccount(new FDAccount(102, "vinu",3500));
		System.out.println("after update");
		fdAccountService.getAllFDAAccounts();

	}

}
