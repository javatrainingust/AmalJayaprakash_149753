/**
 * Class name: FDAccountController
 * 
 * Desc: Controller class for FD Account
 *
 * Date : 15/10/2020
 * 
*/
package com.ust.training.bankmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ust.training.bankmanagement.model.CurrentAccount;
import com.ust.training.bankmanagement.model.FDAccount;
import com.ust.training.bankmanagement.service.FDAccountService;

/** for mapping FD account operations */
@Controller
public class FDAccountController {
	
	/* autowiring FD account service object */
	@Autowired
	FDAccountService fdService;
	
	/** Creating new  FD account   */
	@RequestMapping("/viewfdaccountform")
	public String viewFDAccountForm(Model model) {
		
		FDAccount fd = new FDAccount();
		model.addAttribute("fdaccounts2", fd);
		
		return "addFDAccount";
	}
	
	
	@RequestMapping("/addfdaccount")
	public String addFDAccount(@ModelAttribute("fdAccount") FDAccount fd) {
		
		fdService.addFDAccount(fd);
		
		return "redirect:/allfdaccounts";
	}
	
	/** updating  FD account  */
	@RequestMapping("/updatefdaccount")
	public String updateFDAccount(@ModelAttribute("fdAccount") FDAccount fd) {
		
		fdService.updateFDAccount(fd);
		return "redirect:/allfdaccounts";
	}
	
	
	/** getting all FD account details */
	@RequestMapping("/allfdaccounts")
	public String getAllFDAccounts(Model model) {
		
		List<FDAccount> fd = fdService.getAllFDAAccounts();
		model.addAttribute("fdaccounts", fd);
		
		return "fdAccount";
	}
	
	/** getting specific FD account details */
	@RequestMapping("/viewfdaccount")
	public String getFDAccountByAccountNumber(@RequestParam("acno") int acno, Model model) {
		
		FDAccount fd = fdService.getFDAAccountByAccountNumber(acno);
		model.addAttribute("fdaccounts1", fd);
		
		return "viewFDAccount";
		
	}
	
	/** deleting specific FD account details */
	@RequestMapping("/deletefdaccount")
	public String deleteFDAccountByAccountNumber(@RequestParam("acno") int acno) {
		
		fdService.deleteFDAAccount(acno);
		
		return "redirect:/allfdaccounts";
		
	}
	
	/** sort FD account by A/c holder name */
	@RequestMapping("/sortfdaccountbyname")
	public String getAllFDAccountsSortedByName(Model model) {
		
		List<FDAccount> sorted = fdService.getAllFDAccountsSortedByName();
		model.addAttribute("fdaccounts", sorted);
		return "fdAccount";
	}
	
	/** sort FD account by balance */
	@RequestMapping("/sortfdaccountbybalance")
	public String getAllFDAccountsSortedByBalance(Model model) {
		
		List<FDAccount> sorted = fdService.getAllFDAccountsSortedByBalance();
		model.addAttribute("fdaccounts", sorted);
		return "fdAccount";
	}

}
