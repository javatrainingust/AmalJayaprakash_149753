/**
 * Classname:CurrentAccount
 * 
 * Description:This is a sub class of Account 
 *
 * Date:30/09/2020
 * 
*/
package com.ust.training.bankmanagement.model;
/**
*This is a class used to model Current account operations.
*/
public class CurrentAccount extends Account implements Comparable<CurrentAccount>{
	
	private float overDraftlimit = 1000;
	
	public CurrentAccount(int accountNumber, String accountHolderName, float overDraftlimit) {
		 
		 super(accountNumber, accountHolderName);
		 this.overDraftlimit = overDraftlimit;
		 
	 }
	public CurrentAccount(int accountNumber, String accountHolderName) {
		 
		 super(accountNumber, accountHolderName);
		 
		 
	 }
	public CurrentAccount() {
		 
		 
		 
	 }
	
	
	
	public float getOverDraftlimit() {
		return overDraftlimit;
	}



	public void setOverDraftlimit(float overDraftlimit) {
		this.overDraftlimit = overDraftlimit;
	}



	/**
	*method for checking eligibility for overdrafting
	*/
	public void amountLimit(float balance) {
		
		if(balance < overDraftlimit) {
			
			System.out.println("you are eligible for overdrafting");
		}
		else {
			System.out.println("not eligible");
		}
	}
	/**
	*method for comparing a/c holder names
	*/
	//@Override
	public int compareTo(CurrentAccount currentAccount) {
		return this.getAccountHolderName().compareTo(currentAccount.getAccountHolderName());
	}

}
