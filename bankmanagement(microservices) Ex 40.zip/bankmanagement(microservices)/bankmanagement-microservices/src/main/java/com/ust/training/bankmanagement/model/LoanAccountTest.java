package com.ust.training.bankmanagement.model;

import static org.junit.Assert.*;

import org.junit.Test;

public class LoanAccountTest {

	@Test
	public void testLoanAccount() {
		
		float expected = 30000;
		LoanAccount loanAccount = new LoanAccount();
		loanAccount.setLoanOutStanding(1000);
		loanAccount.setTenture(10);
		loanAccount.calculateEMI();
		
		float actual = loanAccount.getEMI();
		assertEquals(expected, actual, 0);
		
	}

}
