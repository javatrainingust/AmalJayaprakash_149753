/**
 * Class name: LoanAccountController
 * 
 * Desc: Controller class for Loan Account
 *
 * Date : 22/10/2020
 * 
*/
package com.ust.training.bankmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

//import com.ust.training.bankmanagement.model.CurrentAccount;
import com.ust.training.bankmanagement.model.LoanAccount;
//import com.ust.training.bankmanagement.model.SBAccount;
import com.ust.training.bankmanagement.service.LoanAccountService;

/** controller class for mapping operations annotated with @RestController 
 * forms rest services for Loan Account
 * */
@RestController
public class LoanAccountController {
	
	/* autowiring Loan account service object */
	@Autowired
	LoanAccountService laService;
	
	/** for creating Loan Account */
	@PostMapping("/loanAccounts")
	public LoanAccount addLoanAccount(@RequestBody LoanAccount loanAccount) {
		
		laService.addLoanAccount(loanAccount);
		
		return loanAccount;
	}
	
	/** updating  Loan account  */
	@PutMapping("/loanAccounts/{acno}")
	public LoanAccount updateLoanAccount(@PathVariable int acno, 
			@RequestBody LoanAccount loanAccount ) {
		
		LoanAccount oldLoanAccount = laService.getLoanAccountByAccountNumber(acno);
		
		if(oldLoanAccount != null) {
			
			laService.updateLoanAccount(loanAccount);
		}
		
		return loanAccount;
	}
	
	/** getting all Loan account details */
	@GetMapping("/loanAccounts")
	public List<LoanAccount> getAllLoanAccounts() {
		
		List<LoanAccount> loanAccounts = laService.getAllLoanAccounts();
		
		return loanAccounts;
	}
	
	/** getting specific Loan account details */
	@GetMapping("/loanAccounts/{acno}")
	public LoanAccount getLoanAccountByAccountNumber(@PathVariable int acno) {
		
		LoanAccount loanAccount = laService.getLoanAccountByAccountNumber(acno);
	
		return loanAccount;
		
	}
	
	/** deleting specific Loan account details */
	@DeleteMapping("/loanAccounts/{acno}")
	public String deleteLoanAccountByAccountNumber(@PathVariable int acno) {
		
		laService.deleteLoanAccount(acno);
		
		return "deleted Loan Account with A/C no "+acno;
		
	}
	
	/**beloe methods for spring mvc*/
	
	/** sort Loan account by A/c holder name */
	@RequestMapping("/sortloanaccountbyname")
	public String getAllLoanAccountsSortedByName(Model model) {
		
		List<LoanAccount> sorted = laService.getAllLoanAccountsSortedByName();
		model.addAttribute("loanaccounts", sorted);
		return "loanAccount";
	}
	
	/** sort SB account by loan outstanding */
	@RequestMapping("/sortloanaccountbyloanout")
	public String getAllSBAccountsSortedByBalance(Model model) {
		
		List<LoanAccount> sorted = laService.getAllLoanAccountsSortedByLoanOutstanding();
		model.addAttribute("loanaccounts", sorted);
		return "loanAccount";
	}

}
