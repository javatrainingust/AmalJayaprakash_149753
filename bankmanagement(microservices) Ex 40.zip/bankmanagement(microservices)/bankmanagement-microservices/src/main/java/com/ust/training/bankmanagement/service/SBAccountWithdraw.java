
//foe checking withdrawl 
package com.ust.training.bankmanagement.service;

import com.ust.training.bankmanagement.exception.InsufficentBalanceException;
import com.ust.training.bankmanagement.model.SBAccount;

public class SBAccountWithdraw {

	public static void main(String[] args) throws InsufficentBalanceException {
		// TODO Auto-generated method stub
		SBAccountService sbAccountService = new SBAccountService();
		System.out.println("before withdrwal");
		sbAccountService.addSBAccount(new SBAccount(100, "anu",5000));
		System.out.println();
		sbAccountService.getSBAccountByAccountNumber(100).withdrawMoney(4000);
		System.out.println();
		System.out.println("after withdrwal");
		sbAccountService.getSBAccountByAccountNumber(100).getBalance();
		System.out.println();
		System.out.println("with drawing again");
		sbAccountService.getSBAccountByAccountNumber(100).withdrawMoney(1500);
	}

}
