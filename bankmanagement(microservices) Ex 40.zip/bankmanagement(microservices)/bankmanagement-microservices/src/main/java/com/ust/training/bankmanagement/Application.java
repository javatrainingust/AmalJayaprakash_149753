/**
 * Class name: Application
 * 
 * Desc: application class for bankmanagement
 *
 * Date : 27/10/2020
 * 
*/
package com.ust.training.bankmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/** main class for running application annotated with @SpringBootApplication
 * */
@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

}

