/**
 * Classname:CountryDetails
 * 
 * Description:This model class for Country Details
 *
 * Date:22/10/2020
 * 
*/


package com.ust.training.restdemo.model;
/**
*This is a bean class used to model country details.
*/
public class CountryDetails {
	
	private String code;
	private String description;
	
	private String message;
	
	/* getter method for getting code */
	public String getCode() {
		return code;
	}
	/* setter method for setting code */
	public void setCode(String code) {
		this.code = code;
	}
	/* getter method for getting description */
	public String getDescription() {
		return description;
	}
	/* setter method for setting description */
	public void setDescription(String description) {
		this.description = description;
	}
	/* getter method for getting message */
	public String getMessage() {
		return message;
	}
	/* setter method for setting message */
	public void setMessage(String message) {
		this.message = message;
	}
	
	
	

}
