/**
 * Class name: CountryDetailsController
 * 
 * Desc: Controller class for Country Details
 *
 * Date : 122/10/2020
 * 
*/
package com.ust.training.restdemo.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ust.training.restdemo.model.CountryDetails;
/** controller class for mapping operations annotated with @RestController 
 * forms rest services for Country Details
 * */
@RestController
public class CountryDetailsController {
	
	Map<String, CountryDetails> countryDB = new HashMap<String, CountryDetails>();
	
	/* for getting dummy data ,testing purpose */
	@RequestMapping(value = "/countries/dummy", method = RequestMethod.GET)
	public CountryDetails getDummmyCountryDetails() {
		
		CountryDetails countryDetails = new CountryDetails();
		countryDetails.setCode("d");
		countryDetails.setDescription("dummy data");
		countryDetails.setMessage("dummy country retreived");
		
		countryDB.put("IN", countryDetails);
		
		return countryDetails;
		
	}
	
	/* for creating country details */
	@RequestMapping(value = "/countries", method=RequestMethod.POST)
	public CountryDetails createCountryDetails(@RequestBody CountryDetails countryDetails) {
		
		if(countryDB.containsKey(countryDetails.getCode())) {
			
			countryDetails.setMessage("country details already exist with code "+countryDetails.getCode());
		}
		else {
			
			countryDB.put(countryDetails.getCode(), countryDetails);
			countryDetails.setMessage("country details added");
		}
		return countryDetails;
	}
	
	/* for getting all country details */
	@RequestMapping(value = "/countries", method = RequestMethod.GET)
	public List<CountryDetails> getAllCountryDetails() {
		
		List<CountryDetails> countryDetails = new ArrayList<CountryDetails>();
		
		Set<String> countryCode = countryDB.keySet();
		
		for(String c : countryCode) {
			
			countryDetails.add(countryDB.get(c));
		}
		
		return countryDetails;
	}
	
	/* for getting one specific country details */
	@RequestMapping(value = "/countries/{code}", method = RequestMethod.GET)
	public CountryDetails getCountryDetails(@PathVariable String code) {
		
		CountryDetails countryDetails = new CountryDetails();
		
		if(countryDB.containsKey(code) ) {
			
			countryDetails = countryDB.get(code);
			countryDetails.setMessage("country details retrieved");
		}
		else {
			
			countryDetails.setMessage("already exist with code "+countryDetails.getCode());
		}
		
		return countryDetails;
	}
	
	/* for deleting one specific country details */
	@RequestMapping(value = "/countries/{code}", method = RequestMethod.DELETE)
	public CountryDetails deleteCountryDetails(@PathVariable String code) {
		
		CountryDetails countryDetails = new CountryDetails();
		
		if(countryDB.containsKey(code) ) {
			
			countryDetails = countryDB.get(code);
			countryDB.remove(code);
			countryDetails.setMessage("country details deleted ");
		}
		else {
			
			countryDetails.setMessage("country details not found with code "+countryDetails.getCode());
		}
		
		return countryDetails;
	}
	
	/* for updating one specific country details */
	@RequestMapping(value = "/countries/{code}", method = RequestMethod.PUT)
	public CountryDetails updateCountryDetails(@PathVariable String code,
			@RequestBody CountryDetails updatedCountryDetails) {
		
		CountryDetails countryDetails = new CountryDetails();
		
		if(countryDB.containsKey(code) ) {
			
			countryDetails = countryDB.get(code);
			countryDetails.setDescription(updatedCountryDetails.getDescription());
			countryDetails.setMessage("country details updated for code " +countryDetails.getCode());
		}
		else {
			
			countryDetails.setMessage("country details not found with code "+countryDetails.getCode());
		}
		
		return countryDetails;
	}
	
	

}
