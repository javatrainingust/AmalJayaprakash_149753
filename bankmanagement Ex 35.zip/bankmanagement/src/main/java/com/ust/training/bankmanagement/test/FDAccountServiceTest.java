package com.ust.training.bankmanagement.test;

import static org.junit.Assert.*;
import org.junit.Test;

import com.ust.training.bankmanagement.dao.FDAccountDAOImpl;
import com.ust.training.bankmanagement.model.FDAccount;
import com.ust.training.bankmanagement.service.FDAccountService;

public class FDAccountServiceTest {
	
	
	
	  
	  FDAccountService fdAccountService;
	  
	  public FDAccountServiceTest() {
	  
	  fdAccountService = new FDAccountService();
	  fdAccountService.addFDAccount(new FDAccount(100,"anu",5000));
	  fdAccountService.addFDAccount(new FDAccount(101,"manu",2000));
	  fdAccountService.addFDAccount(new FDAccount(102,"vinu",3000));
	  }
	  
	  @Test
	  public void testAddFDAccountSuccess() {
		  	fdAccountService.addFDAccount(new FDAccount(103,"roy",6000));
			int actual = fdAccountService.getAllFDAAccounts().size();
			int expected = 4;
			assertEquals(expected, actual); 
			
		}
		
	  @Test
	  public void testAddFDAccountFailure() {
			fdAccountService.addFDAccount(new FDAccount(102,"ginu",3000));
			String actual = fdAccountService.getFDAAccountByAccountNumber(102).getAccountHolderName();
			System.out.println(actual);
			String expected = "vinu";
			assertEquals(expected, actual); 
			
		}
		
	  @Test 
	  public void testGetAllFDAccounts() { 

		  int actual = fdAccountService.getAllFDAAccounts().size(); 
		  int expected = 3;
		  assertEquals(expected, actual); 
		  
	  }
	  
	  @Test 
	  public void testGetFDAccountByAccountNumber() { 
		  
		  String actual = fdAccountService.getFDAAccountByAccountNumber(100).getAccountHolderName();
		  String expected = "anu";
		  assertEquals(expected, actual); 
		  
	  }
	  
	  
	  @Test 
	  public void testDeleteFDAccount() { 
		  
		  FDAccountDAOImpl fdAccountDAOImpl = new FDAccountDAOImpl();
		  fdAccountDAOImpl.deleteFDAAccount(102);
		  FDAccount actual = fdAccountDAOImpl.getFDAAccountByAccountNumber(102);
		  System.out.println(actual);
		  FDAccount expected = null; 
		  assertEquals(expected,actual); 
		  
	  }
	  
	  @Test 
	  public void testGetAllFDAccountsSortByName() { 
		  String actual = fdAccountService.getAllFDAccountsSortedByName().get(0).getAccountHolderName();
		  String expected = "anu"; 
		  assertEquals(expected, actual); 
		  
	  }
	  
	  @Test 
	  public void testGetAllFDAccountsSortByBalance() { 
		  
		  String actual = fdAccountService.getAllFDAccountsSortedByBalance().get(0).getAccountHolderName(); 
		  System.out.println(actual); 
		  String expected = "manu";
		  assertEquals(expected, actual); 
		  
	  }
	 
	 
	  @Test
	  public void testUpdateFDAccount() {
		  
		fdAccountService.updateFDAccount(new FDAccount(102,"vinu",3500));
		float actual = fdAccountService.getFDAAccountByAccountNumber(102).getBalance();
		System.out.println(actual);
		float expected = 3500;
		assertEquals(expected, actual,0);
		
	}
	
	
	  
	 
	
	

}
