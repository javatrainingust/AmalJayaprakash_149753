/**
 * Interface name:CurrentAccountDAO
 * 
 * Description:This interface is form data access operations
 *
 * Date:06/10/2020
 * 
*/
package com.ust.training.bankmanagement.dao;

import java.util.List;

import com.ust.training.bankmanagement.model.CurrentAccount;
/**
*This interface declare data access operations in Current account.
*/
public interface CurrentAccountDAO {
	
	public List<CurrentAccount> getAllCurrentAccounts();
	public CurrentAccount getCurrentAccountByAccountNumber(int accountNumber);
	public void deleteCurrentAccount(int accountNumber);
	public boolean addCurrentAccount(CurrentAccount currentAccount);
	public void updateCurrentAccount(CurrentAccount currentAccount);

}
