package com.training.bankmanagement.model;

import static org.junit.Assert.*;

import org.junit.Test;

import com.training.bankmanagement.exception.InsufficentBalanceException;

public class AccountTest {

	
	@Test
	public void testAccount() throws InsufficentBalanceException {
		
		float expected = 9000;
		Account account = new Account();
		account.setBalance(10000);
		float actual = account.withdrawMoney(1000);
		
		assertEquals(expected, actual, 0);
		
		
	}

}
