package com.training.bankmanagement.test;

import static org.junit.Assert.*;


import org.junit.Test;

import com.training.bankmanagement.dao.LoanAccountDAOImpl;
import com.training.bankmanagement.model.CurrentAccount;
import com.training.bankmanagement.model.LoanAccount;
import com.training.bankmanagement.service.LoanAccountService;

public class LoanAccountServiceTest {

	LoanAccountService loanAccountService;
	
    public LoanAccountServiceTest() {
	
    	loanAccountService = new LoanAccountService();
    	loanAccountService.addLoanAccount(new LoanAccount(100, "anu",1200));
    	loanAccountService.addLoanAccount(new LoanAccount(101, "manu",400));
    	loanAccountService.addLoanAccount(new LoanAccount(102, "vinu",600));
    }
    
    @Test
	public void testAddLoanAccountSuccess() {
    	loanAccountService.addLoanAccount(new LoanAccount(103,"roy",1500));
		int actual = loanAccountService.getAllLoanAccounts().size();
		int expected = 4;
		assertEquals(expected, actual); 
			
		}
    @Test
	public void testAddLoanAccountFailure() {
    	loanAccountService.addLoanAccount(new LoanAccount(102,"ginu",3000));
		String actual = loanAccountService.getLoanAccountByAccountNumber(102).getAccountHolderName();
		System.out.println(actual);
		String expected = "vinu";
		assertEquals(expected, actual); 
			
		}
	

	@Test
	public void testGetAllLoanAccounts() {
		
		int actual = loanAccountService.getAllLoanAccounts().size();
		int expected = 3;
		assertEquals(expected, actual);
	}
	
	@Test
	public void testGetLoanAccountByAccountNumber() {
		
		String actual = loanAccountService.getLoanAccountByAccountNumber(100).getAccountHolderName();
		String expected = "anu";
		assertEquals(expected, actual);
	}
	
	@Test
	public void testDeleteLoanAccount() {
		LoanAccountDAOImpl loanAccountDAOImpl = new LoanAccountDAOImpl();
		loanAccountDAOImpl.deleteLoanAccount(102);;
		LoanAccount actual = loanAccountDAOImpl.getLoanAccountByAccountNumber(102);
		System.out.println(actual); 
		CurrentAccount expected = null;
		assertEquals(expected, actual);
	}
	
	@Test
	public void testGetAllLoanAccountsSortByName() {
		
		String actual = loanAccountService.getAllLoanAccountsSortedByName().get(0).getAccountHolderName();
		String expected = "anu";
		assertEquals(expected, actual);
	}
	
	@Test
	public void testGetAllLoanAccountsSortByLoanOutstanding() {
		
		String actual = loanAccountService.getAllLoanAccountsSortedByLoanOutstanding().get(0).getAccountHolderName();
		System.out.println(actual);
		String expected = "manu";
		assertEquals(expected, actual);
	}
	
	@Test
	public void testUpdateLoanAccount() {
		  
		loanAccountService.updateLoanAccount(new LoanAccount(102,"vinu",3500));
		float actual = loanAccountService.getLoanAccountByAccountNumber(102).getLoanOutStanding();
		System.out.println(actual);
		float expected = 3500;
		assertEquals(expected, actual,0);
		
	}

}
