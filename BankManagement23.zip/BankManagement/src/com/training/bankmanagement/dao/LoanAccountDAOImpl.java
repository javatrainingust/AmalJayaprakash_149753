/**
 * Classname:LoanAccountDAOImpl
 * 
 * Description:This class is implemented from LoanAccountDAO for data access operations
 *
 * Date:06/10/2020
 * 
*/
package com.training.bankmanagement.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.training.bankmanagement.model.LoanAccount;

/**
*This is a class used for add,delete,get the loan account detalis.
*/
public class LoanAccountDAOImpl implements LoanAccountDAO{
	
	List<LoanAccount> loanAccountList;
	private Set<LoanAccount> loanAccountSet;
	/**
	*constructor for LoanAccountDAOImpl
	*/
	public LoanAccountDAOImpl() {
		 
		loanAccountList = new ArrayList<LoanAccount>();
		loanAccountSet = new HashSet<LoanAccount>();
		
//		loanAccountList.add(new LoanAccount(100, "anu",1200));
//		loanAccountList.add(new LoanAccount(101, "manu",400));
//		loanAccountList.add(new LoanAccount(102, "vinu",600));
		
	}
	/**
	*method for getting all loan accounts
	*method implemented from LoanAccountDAO
	*/
	@Override
	public List<LoanAccount> getAllLoanAccounts() {
		// TODO Auto-generated method stub
		return loanAccountList;
	}
	/**
	*method for getting loan account details by account number
	*method implemented from LoanAccountDAO
	*/
	@Override
	public LoanAccount getLoanAccountByAccountNumber(int accountNumber) {
		// TODO Auto-generated method stub
		LoanAccount loanAccount = null;
		Iterator<LoanAccount> iterator = loanAccountList.iterator();
		while(iterator.hasNext()) {
			
			LoanAccount la = iterator.next();
			
			if(la.getAccountNumber() == accountNumber) {
				
				loanAccount = la;
			}
		}
		return loanAccount;
	}
	/**
	*method for deleting loan  account by account number
	*method implemented from LoanAccountDAO
	*/
	@Override
	public void deleteLoanAccount(int accountNumber) {
		// TODO Auto-generated method stub
		for(int i = 0; i < loanAccountList.size(); i++) {
			
			LoanAccount la = loanAccountList.get(i);
			if(la.getAccountNumber() == accountNumber) {
				
				loanAccountList.remove(i);
			}
		}
		
	}
	
	/**
	*method for adding loan accounts
	*method implemented from LoanAccountDAO
	*/
	@Override
	public boolean addLoanAccount(LoanAccount loanAccount) {
		// TODO Auto-generated method stub
		boolean isAdded = loanAccountSet.add(loanAccount);
		if(isAdded) {
			loanAccountList.add(loanAccount);
		}
		return isAdded;
	}
	
	/**
	*method for updating loan accounts
	*method implemented from LoanAccountDAO
	*/
	@Override
	public void updateLoanAccount(LoanAccount loanAccount) {
		// TODO Auto-generated method stub
		Iterator<LoanAccount> iterator = loanAccountList.iterator();
		while(iterator.hasNext()) {
			LoanAccount la = iterator.next();
			
			if(la.getAccountNumber() == loanAccount.getAccountNumber()) {
				
				la.setAccountHolderName(loanAccount.getAccountHolderName());
				la.setLoanOutStanding(loanAccount.getLoanOutStanding());
			}
			
		}
	}

}
