package com.training.bankmanagement.service;

import com.training.bankmanagement.model.LoanAccount;

public class LoanAccountDelete {
	
public static void main(String[] args) {
		
		LoanAccountService loanAccountService = new LoanAccountService();
		loanAccountService.addLoanAccount(new LoanAccount(100, "anu",1200));
		loanAccountService.addLoanAccount(new LoanAccount(101, "manu",400));
		loanAccountService.addLoanAccount(new LoanAccount(102, "vinu",600));
		System.out.println("all loan accounts");
		loanAccountService.getAllLoanAccounts();
		System.out.println();
		
		loanAccountService.deleteLoanAccount(102);
		System.out.println("deleted");
		System.out.println("after deletion");
		loanAccountService.getAllLoanAccounts();
		
	}

}
