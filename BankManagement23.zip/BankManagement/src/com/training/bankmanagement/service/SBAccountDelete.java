package com.training.bankmanagement.service;

import com.training.bankmanagement.model.SBAccount;

public class SBAccountDelete {
	
public static void main(String[] args) {
		
		SBAccountService sbAccountService = new SBAccountService();
		sbAccountService.addSBAccount(new SBAccount(100, "anu",15000));
		sbAccountService.addSBAccount(new SBAccount(101, "manu",22000));
		sbAccountService.addSBAccount(new SBAccount(102, "vinu",3000));
		System.out.println("all savings accounts");
		sbAccountService.getAllSBAccounts();
		System.out.println();
		
		sbAccountService.deleteSBAccount(102);
		System.out.println("deleted");
		System.out.println("after deletion");
		sbAccountService.getAllSBAccounts();
		
	}

}
