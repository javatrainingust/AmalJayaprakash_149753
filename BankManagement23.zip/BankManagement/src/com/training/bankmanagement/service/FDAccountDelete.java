package com.training.bankmanagement.service;

import com.training.bankmanagement.model.FDAccount;

public class FDAccountDelete {
	
public static void main(String[] args) {
		
		FDAccountService fdAccountService = new FDAccountService();
		fdAccountService.addFDAccount(new FDAccount(100, "anu",5000));
		fdAccountService.addFDAccount(new FDAccount(101, "manu",2000));
		fdAccountService.addFDAccount(new FDAccount(102, "vinu",3000));
		System.out.println("all fixed accounts");
		fdAccountService.getAllFDAAccounts();
		System.out.println();
		
		fdAccountService.deleteFDAAccount(102);
		System.out.println("deleted");
		System.out.println("after deletion");
		fdAccountService.getAllFDAAccounts();
		
	}
	

}
