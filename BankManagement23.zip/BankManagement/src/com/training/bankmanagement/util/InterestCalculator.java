/**
 * Interface name:InterestCalculator
 * 
 * Description:This is a interface for implementing calculating related 
   operations 
 *
 * Date:30/09/2020
 * 
*/
package com.training.bankmanagement.util;

/**
 * providing methods for implementing in classes that implements InterestCalculator	
 */
 	

public interface InterestCalculator {
	
	/**
	*method declared for finding interest for savings account.
	*/
	public float calculateSimpleInterest(double rate);
	
	/**
	*method declared for finding interest for fixed deposit account.
	*/
	public float calculateSimpleInterest(double rate, float additional);
	

}
