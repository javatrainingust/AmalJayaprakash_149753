package com.bankmanagement.service;

import com.bankmanagement.model.FDAccount;
import com.bankmanagement.model.SBAccount;

public class InterestCalculatorService {
	
	public static void main(String args[]) {
		
		FDAccount fdAccount = new FDAccount();
		fdAccount.setAccountHolderName("Rejin");
		fdAccount.setAccountNumber(296);
		fdAccount.setRate(5);
		fdAccount.setAdditional(10);
		System.out.println("a/c holder :"+fdAccount.getAccountHolderName());
		System.out.println("a/c no :"+fdAccount.getAccountNumber());
		fdAccount.calculateSimpleInterest();
		
		System.out.println();
		
		SBAccount sbAccount = new SBAccount();
		sbAccount.setAccountHolderName("jeeva");
		sbAccount.setAccountNumber(326);
		sbAccount.setRate(5);
		System.out.println("a/c holder :"+sbAccount.getAccountHolderName());
		System.out.println("a/c no :"+sbAccount.getAccountNumber());
		sbAccount.calculateSimpleInterest();
	}

}
