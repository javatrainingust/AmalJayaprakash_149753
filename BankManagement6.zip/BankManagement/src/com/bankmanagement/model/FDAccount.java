package com.bankmanagement.model;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.bankmanagement.util.InterestCalculator;

public class FDAccount extends Account implements Renewable{
	
	 //private int tenure;
	 private boolean isAutoRenewal;
	 private float rate;
	 private float principal;
	 private float additional;
	 

	 
	 private InterestCalculator interestCalculator
		= new InterestCalculator();
	 
	public float getRate() {
		return rate;
	}
	
	public float getAdditional() {
		return additional;
	}

	public void setAdditional(float additional) {
		this.additional = additional;
	}

	public float getPrincipal() {
		return principal;
	}




	public void setPrincipal(float principal) {
		this.principal = principal;
	}


	public void setRate(float rate) {
		this.rate = rate;
	}

	public boolean isAutoRenewal() {
		return isAutoRenewal;
	}
	public void setAutoRenewal(boolean isAutoRenewal) {
		this.isAutoRenewal = isAutoRenewal;
	}
	
	// implementing autorenewal from Renewal
	@Override
	public void autoRenewal(int tenure) {
		// TODO Auto-generated method stub
		if(isAutoRenewal == true) {
			
			if(tenure <12) {
				
				System.out.println("please auto renew before maturity date");
			}
			else {
			System.out.println("auto renewed ");
			}
		}
		System.out.println("autorenewel option is not selected");
			
			
		}
		
		
	
	//
	
//	public void autorenew() {
//		
//		if(isAutoRenewal == true ) {
//			
//			if(tenure == 12) {
//				System.out.println("please auto renew");
//			}
//			else if(tenure<12) 
//			System.out.println("auto renew before renewel date");
//			else {
//				System.out.println("auto renewed");
//			}
//		}
//		else {
//			System.out.println("you are not set to autorenewel mode");
//		}
//	}
	
//			
	
	//from util calculating simple interest
		public void calculateSimpleInterest() {
			 
			 this.simpleIntr = interestCalculator.calculateSimpleInterest(rate,additional);
			 System.out.println("Interest in FD: "+simpleIntr);
		 }
	//from base class 
	@Override
	public void calculateInterest() {
		
		intr = (principal*rate*1)/100;
		System.out.println(" interest at FD :" +intr);
	}
		
		
	}
	
	
	 
	 
	 
	


