package com.bankmanagement.util;

public class InterestCalculator {
	
	private double principalAmount = 1000;
	private int period = 1;
	//private float rate;

	public float calculateSimpleInterest(double rate) {
		
		float simpleIntr = (float) (principalAmount*period*rate)/100;
		return simpleIntr;
	}
	
	//for FD account will get additional 10 as interest
	
	public float calculateSimpleInterest(double rate, float additional) {
		
	
		float simpleIntr = (float) (principalAmount*period*rate)/100 +additional;
		return simpleIntr;
	}
	
	

}
