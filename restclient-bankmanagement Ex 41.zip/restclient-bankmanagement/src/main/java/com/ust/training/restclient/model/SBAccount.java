/**
 * Classname:SBAccount
 * 
 * Description:This is a sub class of Account
 *
 * Date:30/09/2020
 * 
*/
package com.ust.training.restclient.model;

//import com.ust.training.bankmanagement.util.InterestCalculator;

/**
*This is a class used to model Savings bank  account operations.
*/
public class SBAccount extends Account implements Comparable<SBAccount>{
	
	private double interest;
	private float rate;
	private float principal;
	

	/**
	*no arg constructor for SBAccount
	*/
	public SBAccount() {
		
	}
	
	/**
	*param  constructors for SBAccount
	*/
	public SBAccount(int accountNumber, String accountHolderName,float rate, float principal) {
		super(accountNumber, accountHolderName); 
		this.rate = rate;
		this.principal = principal;
	}
	
	public SBAccount(int accountNumber, String accountHolderName, float balance) {
		 
		 super(accountNumber, accountHolderName, balance);
		 
	 }
	
		/*
		 * public SBAccount(int accountNumber, String accountHolderName) {
		 * 
		 * super(accountNumber, accountHolderName);
		 * 
		 * }
		 */



	/**
	 * Accessor method for principal
	 */
	public float getPrincipal() {
		return principal;
	}




	/**
	 * Accessor method for principal
	 */
	public void setPrincipal(float principal) {
		this.principal = principal;
	}




	/**
	 * Accessor method for Interest
	 */
	public double getInterest() {
		return interest;
	}



	/**
	 * Accessor method for Interest
	 */
	public void setInterest(double interest) {
		this.interest = interest;
	}



	/**
	 * Accessor method for Rate
	 */
	public double getRate() {
		return rate;
	}



	/**
	 * Accessor method for Interest
	 */
	public void setRate(float rate) {
		this.rate = rate;
	}




	/**
	*overriding method from Account class
	*method for finding interest
	*/
	
	@Override
	public void calculateInterest() {
		
		intr = (principal*rate*1)/100;
		System.out.println(" interest at SB:" +intr);
	}



	/**
	*method for finding simple interest
	*/
	/*
	 * public void calculateSimpleInterest(InterestCalculator interestCalculator) {
	 * 
	 * this.simpleIntr = interestCalculator.calculateSimpleInterest(rate);
	 * System.out.println("Interest in SB: "+simpleIntr); }
	 */
	
	/**
	*method for comparing a/c holder names
	*/
	//@Override
	public int compareTo(SBAccount sbAccount) {
		return this.getAccountHolderName().compareTo(sbAccount.getAccountHolderName());
	}



}
