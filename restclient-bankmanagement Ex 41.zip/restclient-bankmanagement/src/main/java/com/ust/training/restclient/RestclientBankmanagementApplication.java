/**
 * Classname:RestclientBankmanagementApplication
 * 
 * Description:Rest client class for Bankmanagement
 *
 * Date:28/10/2020
 * 
*/

package com.ust.training.restclient;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.ust.training.restclient.model.SBAccount;
/**
 * this is a rest client class for SBACCount
 * */
@SpringBootApplication
public class RestclientBankmanagementApplication {
	
	/**
	 *main method calling methods 
	 **/
	public static void main(String[] args) {
		
		SpringApplication.run(RestclientBankmanagementApplication.class, args);
		
		getAllSBAccounts();
		
		//getSBAccount();
		
		addSBAccount();
		
		//updateSBAccount();
		
		//deleteSBAccount();
		
	}
	
	/**
	 * method for getting specific SBAccount
	  */
	public static void getSBAccount() {
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8080/bankmanagement/sbAccounts/{acno}";
		
		Map<String, Integer> params = new HashMap<String, Integer>();
		
		params.put("acno", 500);
		
		SBAccount sbAccount = restTemplate.getForObject(uri, SBAccount.class, params);
		
		System.out.println("Account number :" +sbAccount.getAccountNumber());
		System.out.println("A/c holder name :" +sbAccount.getAccountHolderName());
		System.out.println("Balance :" +sbAccount.getBalance());
	}
	

	/**
	 * method for getting all SBAccount
	  */
	public static void getAllSBAccounts() {
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8080/bankmanagement/sbAccounts";
		
		ResponseEntity<SBAccount[]> responseEntity = restTemplate.getForEntity(uri, SBAccount[].class);
		
		SBAccount[] sbAccounts = responseEntity.getBody();
		
		for(int i = 0; i<sbAccounts.length; i++) {
			
			SBAccount sb = sbAccounts[i];
			
			System.out.println("Account number :" +sb.getAccountNumber());
			System.out.println("A/c holder name :" +sb.getAccountHolderName());
			System.out.println("Balance :" +sb.getBalance());
		}
		
	}
	
	/**
	 * method for adding new SBAccount
	  */
	public static void addSBAccount() {
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8080/bankmanagement/sbAccounts";
		
		SBAccount sbAccount = new SBAccount(800, "anu", 5000);
		
		SBAccount sb = restTemplate.postForObject(uri, sbAccount, SBAccount.class);
		
		
	}
	
	/**
	 * method for updating SBAccount
	  */
	public static void updateSBAccount() {
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8080/bankmanagement/sbAccounts/{acno}";
		
		Map<String, Integer> params = new HashMap<String, Integer>();
		
		params.put("acno", 800);
		
		SBAccount sbAccount = new SBAccount(800, "anu john", 5000);
		
		restTemplate.put(uri, sbAccount, params);
		
	}
	

	/**
	 * method for deleting SBAccount
	  */
	
	public static void deleteSBAccount() {
		
RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8080/bankmanagement/sbAccounts/{acno}";
		
		Map<String, Integer> params = new HashMap<String, Integer>();
		
		params.put("acno", 800);
		
		restTemplate.delete(uri, params);
	}
	
	

}
