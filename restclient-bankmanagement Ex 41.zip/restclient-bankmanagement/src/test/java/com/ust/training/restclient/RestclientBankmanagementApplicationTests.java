package com.ust.training.restclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestclientBankmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
