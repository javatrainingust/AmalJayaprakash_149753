/**
 * Classname:SBAccountDAOSQLImpl
 * 
 * Description:This class is implemented from SBAccountDAO for data access operations from MySQL database
 *
 * Date:23/10/2020
 * 
*/
package com.ust.training.bankmanagement.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ust.training.bankmanagement.model.SBAccount;
/**
*This is a class used for add,delete,get the Savings account data access operations
*and forms Repository for SB account.
*/
@Repository
public class SBAccountDAOSQLImpl implements SBAccountDAO{
	/*Declaring Datasource  */
	private DataSource dataSource;
	
	/*Declaring JDBC template */
	private JdbcTemplate jdbcTemplate;
	
	/**
	 * Constructor based dependency injection for Datasource
	 *  creating a JdbcTemplate object using  datasource.
	 * */
	@Autowired
	public void setDataSource(DataSource dataSource) {
		
		this.dataSource = dataSource;
		
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	/**
	*method for getting all savings accounts
	*method implemented from SBAccountDAO
	*/
	public List<SBAccount> getAllSBAccounts() {
		// TODO Auto-generated method stub
		String sql = "select * from sbaccount";
		
		List<SBAccount> sbAccounts = jdbcTemplate.query(sql,new SBAccountMapper());
		return sbAccounts;
	}

	
	/**
	*method for getting savings account details by account number
	*method implemented from SBAccountDAO
	*/
	public SBAccount getSBAccountByAccountNumber(int accountNumber) {
		// TODO Auto-generated method stub
		String sql = "select * from sbaccount where accountnumber = ?";
		
		SBAccount sbAccount = jdbcTemplate.queryForObject(sql, new Object[] 
				{accountNumber}, new SBAccountMapper());
		
		return sbAccount;
	}
	
	/**
	*method for deleting savings  account by account number
	*method implemented from SBAccountDAO
	*/
	public void deleteSBAccount(int accountNumber) {
		// TODO Auto-generated method stub
		String sql = "delete from sbaccount where accountnumber = '"
				+accountNumber+"'";
		jdbcTemplate.update(sql);
	}
	
	/**
	*method for adding savings account 
	*method implemented from SBAccountDAO
	*/
	public boolean addSBAccount(SBAccount sbAccount) {
		// TODO Auto-generated method stub
		String sql = "insert into sbaccount" +
		 "(accountnumber, accountholdername, intr, simpleintr, interest,"
		 + " rate, principal, balance)"
		  +"VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		
		jdbcTemplate.update(sql, new Object[] {
				sbAccount.getAccountNumber(),
				sbAccount.getAccountHolderName(),
				sbAccount.getIntr(),
				sbAccount.getSimpleIntr(),
				sbAccount.getInterest(),
				sbAccount.getRate(),
				sbAccount.getPrincipal(),
				sbAccount.getBalance()});
		return true;
	}
	
	/**
	*method for updating savings account 
	*method implemented from SBAccountDAO
	*/
	public void updateSBAccount(SBAccount sbAccount) {
		// TODO Auto-generated method stub
		String sql = "update sbaccount set accountholdername = '"+sbAccount.getAccountHolderName()
		+"', balance = '"+sbAccount.getBalance()+"' "
				+ "where accountnumber = '"+sbAccount.getAccountNumber()+"'";
		
		jdbcTemplate.update(sql);
	}

}
