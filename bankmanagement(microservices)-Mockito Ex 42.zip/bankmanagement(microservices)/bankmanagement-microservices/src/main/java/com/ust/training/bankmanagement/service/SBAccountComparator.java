/**
 * Classname:SBAccountComparator
 * 
 * Description:This class is implemented from Comparator
 *
 * Date:07/10/2020
 * 
*/
package com.ust.training.bankmanagement.service;

import java.util.Comparator;

import com.ust.training.bankmanagement.model.SBAccount;
/**
*This is a class used sorting SB accounts based on balance.
*/
public class SBAccountComparator implements Comparator<SBAccount>{
	
	/**
	 * method for sort by balnce
	 */
	//@Override
	public int compare(SBAccount sb1, SBAccount sb2) {
		// TODO Auto-generated method stub
		return (int) (sb1.getBalance() - sb2.getBalance());
	}

}
