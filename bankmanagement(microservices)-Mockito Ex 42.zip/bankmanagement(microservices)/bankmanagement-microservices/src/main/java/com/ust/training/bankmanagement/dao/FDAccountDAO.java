/**
 * Interface name:FDAccountDAO
 * 
 * Description:This interface is form data access operations
 *
 * Date:06/10/2020
 * 
*/
package com.ust.training.bankmanagement.dao;

import java.util.List;

import com.ust.training.bankmanagement.model.FDAccount;
/**
*This interface declare data access operations in FD.
*/
public interface FDAccountDAO {
	
	public List<FDAccount> getAllFDAAccounts();
	public FDAccount getFDAAccountByAccountNumber(int accountNumber);
	public void deleteFDAAccount(int accountNumber);
	public boolean addFDAccount(FDAccount fdAccount);
	public void updateFDAccount(FDAccount fdAccount);

}
