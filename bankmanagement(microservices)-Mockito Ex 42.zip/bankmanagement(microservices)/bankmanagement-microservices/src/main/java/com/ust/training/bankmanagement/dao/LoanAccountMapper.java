/**
 * Classname:LoanAccountMapper
 * 
 * Description:This class is implemented from RowMapper interface
 *
 * Date:23/10/2020
 * 
*/
package com.ust.training.bankmanagement.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ust.training.bankmanagement.model.LoanAccount;
/**
 * This class used by jdbc template for mapping rows of resultset
 * */
public class LoanAccountMapper implements RowMapper<LoanAccount> {
	
	
	/**
	 * method to map each row of data in the ResultSet.
	 * */
	public LoanAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		LoanAccount loanAccount = new LoanAccount();
		
		loanAccount.setAccountNumber(rs.getInt("accountnumber"));
		loanAccount.setAccountHolderName(rs.getString("accountholdername"));
		loanAccount.setEMI(rs.getFloat("emi"));
		loanAccount.setLoanOutStanding(rs.getFloat("loanoutstanding"));
		loanAccount.setTenture(rs.getInt("tenture"));
		
		return loanAccount;
	}

}
