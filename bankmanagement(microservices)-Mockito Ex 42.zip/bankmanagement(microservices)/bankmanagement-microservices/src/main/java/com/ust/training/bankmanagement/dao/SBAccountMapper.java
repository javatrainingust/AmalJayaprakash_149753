/**
 * Classname:SBAccountMapper
 * 
 * Description:This class is implemented from RowMapper interface
 *
 * Date:23/10/2020
 * 
*/
package com.ust.training.bankmanagement.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ust.training.bankmanagement.model.SBAccount;
/**
 * This class used by jdbc template for mapping rows of resultset
 * */
public class SBAccountMapper implements RowMapper<SBAccount> {
	
	/**
	 * method to map each row of data in the ResultSet.
	 * */
	public SBAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		SBAccount sbAccount = new SBAccount();
		
		sbAccount.setAccountNumber(rs.getInt("accountnumber"));
		sbAccount.setAccountHolderName(rs.getString("accountholdername"));
		sbAccount.setBalance(rs.getFloat("balance"));
		sbAccount.setIntr(rs.getFloat("intr"));
		sbAccount.setSimpleIntr(rs.getFloat("simpleintr"));
		sbAccount.setInterest(rs.getDouble("interest"));
		sbAccount.setRate(rs.getFloat("rate"));
		sbAccount.setPrincipal(rs.getFloat("principal"));
		
		return sbAccount;
	}

}
