/**
 * Classname:LoanAccountComparator
 * 
 * Description:This class is implemented from Comparator
 *
 * Date:07/10/2020
 * 
*/
package com.ust.training.bankmanagement.service;

import java.util.Comparator;

import com.ust.training.bankmanagement.model.LoanAccount;
/**
*This is a class used sorting loan accounts based on loan outstanding.
*/
public class LoanAccountComparator implements Comparator<LoanAccount> {
	
	/**
	 * method for sort by loan outstanding
	 */
	//@Override
	public int compare(LoanAccount la1, LoanAccount la2) {
		// TODO Auto-generated method stub
		return (int) (la1.getLoanOutStanding() - la2.getLoanOutStanding());
	}

}
