package com.ust.training.bankmanagement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import com.ust.training.bankmanagement.dao.SBAccountDAO;
import com.ust.training.bankmanagement.model.SBAccount;
import com.ust.training.bankmanagement.service.SBAccountService;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
class ApplicationTests {
	
	@Mock
	private SBAccountDAO sbAccountDAOMock;
	
	@InjectMocks
	private SBAccountService sbService;
	
	

	@Test
	public void testGetAllSBAccountsGreaterThanSpecificBalance() {
		
		List<SBAccount> sbAccounts = new ArrayList<>();
		
		sbAccounts.add(new SBAccount(300, "rose", 65000));
		sbAccounts.add(new SBAccount(301, "john", 40000));
		sbAccounts.add(new SBAccount(302, "mary", 50000));
		sbAccounts.add(new SBAccount(303, "mahi", 58000));
		sbAccounts.add(new SBAccount(304, "virat", 35000));
		
		when(sbAccountDAOMock.getAllSBAccounts()).thenReturn(sbAccounts);
		
		int expected = 2;
		int actual = sbService.getAllSBAccountsGreaterThanSpecificBalance(55000).size();
		
		assertEquals(expected, actual);
		
	}

}
