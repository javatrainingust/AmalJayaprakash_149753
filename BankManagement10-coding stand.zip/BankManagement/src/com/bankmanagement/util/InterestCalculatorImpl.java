/**
 * Classname:InterestCalculatorImpl
 * 
 * Description:This class is implemented from InterestCalculator interface
 *
 * Date:30/09/2020
 * 
*/
package com.bankmanagement.util;


/**
*This is a class used for Interest calculation operations.
*/
public class InterestCalculatorImpl implements InterestCalculator {
	
	private double principalAmount = 1000;
	private int period = 1;
	
	
	/**
	*method for calculating saving bank interest
	*/
	public float calculateSimpleInterest(double rate) {
		
		float simpleIntr = (float) (principalAmount*period*rate)/100;
		return simpleIntr;
	}
	

	/**
	*method for calculating fixed deposit interest
	*/
	public float calculateSimpleInterest(double rate, float additional) {
		
		
		float simpleIntr = (float) (principalAmount*period*rate)/100 +additional;
		return simpleIntr;
	}
	
	

}
