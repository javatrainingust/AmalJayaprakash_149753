/**
 * Classname:CurrentAccount
 * 
 * Description:This is a sub class of Account 
 *
 * Date:30/09/2020
 * 
*/
package com.bankmanagement.model;
/**
*This is a class used to model Current account operations.
*/
public class CurrentAccount extends Account{
	
	private float overDraftlimit = 1000;
	
	/**
	*method for checking eligibility for overdrafting
	*/
	public void amountLimit(float balance) {
		
		if(balance < overDraftlimit) {
			
			System.out.println("you are eligible for overdrafting");
		}
		else {
			System.out.println("not eligible");
		}
	}

}
