/**
*StreamDemo1
*class for map,filter demo
*
*/
package com.training.javastreamssort.demo;

import java.util.stream.Stream;

public class StreamDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stream<Integer> numberStream = Stream.of( 1,2,3,4,5,6,7,8,9);
		/*map to produce another streams and filter to perform operation in that stream*/
		long count = numberStream.map((m) -> (m*2)).filter((f) -> f>10).count();
		System.out.println("count :" +count);
	}

}
