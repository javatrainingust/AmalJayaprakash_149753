
package com.training.javastreamssort.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;



public class CatSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Cat> catList = new ArrayList<>();
		catList.add(new Cat("jack", 7));
		catList.add(new Cat("kitty", 2));
		catList.add(new Cat("rose", 3));
		catList.add(new Cat("nikki", 1));
		
		/*sorting cat based on age and printing*/
		Stream<Cat> catListSorted = catList.stream().sorted();
		catListSorted.forEach((c) -> System.out.println(c));

	}

}
