/**
*StreamStudentSort
*class for sort,foreach demo
*
*/
package com.training.javastreamssort.demo;

import java.util.stream.Stream;

public class StreamStudentSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*sorting student streams*/
		Stream<String> students = Stream.of("vimal","jeeva","anu","joy").sorted();
		students.forEach((s) -> System.out.println(s));
	}

}
