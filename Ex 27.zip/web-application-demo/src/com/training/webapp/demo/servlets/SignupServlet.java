/**
 *Classs name: SignupServlet
 * 
 * Desc: Implemented from HttpServlet
 * 
 * Date :14/10/2020
 * 
 */
package com.training.webapp.demo.servlets;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import javax.servlet.ServletException;

import com.training.webapp.demo.model.Signup;
/**
 * Servlet implementation class StudentDetailsServlet
 */
@WebServlet("/signupservlet")
public class SignupServlet extends HttpServlet{
	
	private static final long serialVersionUID = 1L;
    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignupServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Signup signup = new Signup();
		
		signup.setuserName(request.getParameter("username"));
		
		signup.setUserId(request.getParameter("userid"));
		
		signup.setPassword(request.getParameter("password"));
		
		signup.setConfirmPassword(request.getParameter("confirmPassword"));
		
		request.setAttribute("signupKey", signup);
		
		request.getRequestDispatcher("confirm.jsp").forward(request,response);
	}


}
