/**
 *Classs name: Signup
 * 
 * Desc: Class for modeling Signup
 * 
 * Date :14/10/2020
 * 
 */
package com.training.webapp.demo.model;
/**
 * bean class for signup
 */
public class Signup {
	
	private String username;
	private String userId;
	private String password;
	private String confirmPassword;
	
	/* getters and setters method for attributes */
	public String getuserName() {
		return username;
	}
	public void setuserName(String username) {
		this.username = username;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	
	

}
