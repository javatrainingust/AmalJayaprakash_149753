/**
 * Class name: CurrentAccountController
 * 
 * Desc: Controller class for Current Account
 *
 * Date : 15/10/2020
 * 
*/

package com.ust.training.bankmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ust.training.bankmanagement.model.CurrentAccount;
import com.ust.training.bankmanagement.service.CurrentAccountService;
/** for mapping current account operations */
@Controller
public class CurrentAccountController {
	/* autowiring current account service object */
	@Autowired
	CurrentAccountService caService;
	/* getting all current account details */
	@RequestMapping("/allcurrentaccounts")
	public String getAllCurrentAccounts(Model model) {
		
		List<CurrentAccount> current = caService.getAllCurrentAccounts();
		model.addAttribute("currentaccounts", current);
		
		return "currentAccount";
	}

}
