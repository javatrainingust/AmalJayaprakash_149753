/**
 * Interfacename:Renewable
 * 
 * Description:This is a interface for implementing Renewable related operations.
 *
 * Date:30/09/2020
 * 
*/
package com.ust.training.bankmanagement.model;

/**
*This is a Interface used to declare autoRenewal related methods.
*/
public interface Renewable {
	/**
	*method declared for finding auto renewal status.
	*/
	public void autoRenewal(int tenure);

}
