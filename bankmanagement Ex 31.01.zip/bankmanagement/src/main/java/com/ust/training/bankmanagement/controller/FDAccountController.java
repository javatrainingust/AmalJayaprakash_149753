/**
 * Class name: FDAccountController
 * 
 * Desc: Controller class for FD Account
 *
 * Date : 15/10/2020
 * 
*/
package com.ust.training.bankmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.ust.training.bankmanagement.model.FDAccount;
import com.ust.training.bankmanagement.service.FDAccountService;

/** for mapping FD account operations */
@Controller
public class FDAccountController {
	
	/* autowiring FD account service object */
	@Autowired
	FDAccountService fdService;
	/* getting all FD account details */
	@RequestMapping("/allfdaccounts")
	public String getAllFDAccounts(Model model) {
		
		List<FDAccount> fd = fdService.getAllFDAAccounts();
		model.addAttribute("fdaccounts", fd);
		
		return "fdAccount";
	}

}
