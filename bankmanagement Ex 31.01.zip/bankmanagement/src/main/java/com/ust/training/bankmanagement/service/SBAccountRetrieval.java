package com.ust.training.bankmanagement.service;


import com.ust.training.bankmanagement.model.SBAccount;

public class SBAccountRetrieval {
	
public static void main(String[] args) {
		
		SBAccountService sbAccountService = new SBAccountService();
		
		sbAccountService.addSBAccount(new SBAccount(100, "anu",5000));
		sbAccountService.addSBAccount(new SBAccount(101, "manu",2000));
		sbAccountService.addSBAccount(new SBAccount(102, "binu",3000));
		
		System.out.println("all savings accounts");
		sbAccountService.getAllSBAccounts();
		
		System.out.println();
		System.out.println("savings account details");
		sbAccountService.getSBAccountByAccountNumber(100);
		
		System.out.println();
		System.out.println("by a/c holder name");
		sbAccountService.getAllSBAccountsSortedByName();
		
		System.out.println();
		System.out.println("by balance");
		sbAccountService.getAllSBAccountsSortedByBalance();
		
	}

}
