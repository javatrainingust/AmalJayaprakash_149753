package com.ust.training.bankmanagement.model;
import com.ust.training.bankmanagement.exception.InsufficentBalanceException;
import static org.junit.Assert.*;

import org.junit.Test;


public class AccountTest {

	
	@Test
	public void testAccount() throws InsufficentBalanceException {
		
		float expected = 9000;
		Account account = new Account();
		account.setBalance(10000);
		float actual = account.withdrawMoney(1000);
		
		assertEquals(expected, actual, 0);
		
		
	}

}
