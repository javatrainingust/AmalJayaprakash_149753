/**
 * Classname:FDAccountComparator
 * 
 * Description:This class is implemented from Comparator
 *
 * Date:07/10/2020
 * 
*/
package com.ust.training.bankmanagement.service;

import java.util.Comparator;

import com.ust.training.bankmanagement.model.FDAccount;
/**
*This is a class used sorting fd accounts based on balance.
*/
public class FDAccountComparator implements Comparator<FDAccount>{
	
	/**
	 * method for sort by balnce
	 */
	//@Override
	public int compare(FDAccount fd1, FDAccount fd2) {
		// TODO Auto-generated method stub
		return (int) (fd1.getBalance() - fd2.getBalance());
	}

}
