/**
 * Class name: LoanAccountController
 * 
 * Desc: Controller class for Loan Account
 *
 * Date : 15/10/2020
 * 
*/
package com.ust.training.bankmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.ust.training.bankmanagement.model.LoanAccount;
import com.ust.training.bankmanagement.service.LoanAccountService;

/** for mapping Loan account operations */
@Controller
public class LoanAccountController {
	
	/* autowiring Loan account service object */
	@Autowired
	LoanAccountService laService;
	
	/* getting all Loan account details */
	@RequestMapping("/allloanaccounts")
	public String getAllLoanAccounts(Model model) {
		
		List<LoanAccount> la = laService.getAllLoanAccounts();
		model.addAttribute("loanaccounts", la);
		
		return "loanAccount";
	}
	

}
