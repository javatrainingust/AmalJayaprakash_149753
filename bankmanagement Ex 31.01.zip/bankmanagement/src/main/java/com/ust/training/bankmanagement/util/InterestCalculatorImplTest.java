package com.ust.training.bankmanagement.util;

import static org.junit.Assert.*;

import org.junit.Test;

import com.ust.training.bankmanagement.model.FDAccount;
import com.ust.training.bankmanagement.model.SBAccount;

public class InterestCalculatorImplTest {

	@Test
	public void testCalculateSimpleInterestOfSBAccount() {
		
		float expected = 50;
		InterestCalculatorImpl interestCalculatorImpl = new InterestCalculatorImpl();
		
		SBAccount sbAccount = new SBAccount();
		sbAccount.setRate(5);
		
		sbAccount.calculateSimpleInterest(interestCalculatorImpl);
		float actual =sbAccount.getSimpleIntr();
		assertEquals(expected, actual, 0);
	}
	
	@Test
	public void testCalculateSimpleInterestOfFDAccount() {
		
		float expected = 60;
		InterestCalculatorImpl interestCalculatorImpl = new InterestCalculatorImpl();
		
		FDAccount fdAccount = new FDAccount(200, "ravi");
		fdAccount.setRate(5);
		fdAccount.setAdditional(10);
		fdAccount.calculateSimpleInterest(interestCalculatorImpl);
		float actual =fdAccount.getSimpleIntr();
		assertEquals(expected, actual, 0);
	}

}
