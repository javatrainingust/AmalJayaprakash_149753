/**
 *Classs name: SpringConfig
 * 
 * Desc: Configuration class instead of xml
 * 
 * Date :13/10/2020
 * 
 */
package com.training.spring.demo;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** java config class */
@Configuration
public class Config {
	
	/*bean object creation */
	@Bean(name = "organizerBean")
	public Organizer getOrganizer() {
		
		Organizer org= new Organizer();
		return org;
	}

}
