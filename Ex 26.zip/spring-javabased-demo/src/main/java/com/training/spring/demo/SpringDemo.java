/**
 *Classs name: SpringDemo
 * 
 * Desc: main class
 * 
 * Date :13/10/2020
 * 
 */
package com.training.spring.demo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SpringDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(Config.class);
		
		Organizer organizer = context.getBean("organizerBean", Organizer.class);
		
		organizer.sayGreetings();

	}

}
