/**
 *Classs name: Saxophone
 * 
 * Desc: Implemented from Instrument interface
 * 
 * Date :13/10/2020
 * 
 */
package com.training.spring.demo;


/** bean class for saxophone with Component annotation*/

public class Saxophone implements Instrument {
	
	/* method implemented from instrument*/
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("playing saxophone");
		
	}

}
