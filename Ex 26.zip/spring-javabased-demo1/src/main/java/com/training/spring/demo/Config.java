/**
 *Classs name: SpringConfig
 * 
 * Desc: Configuration class instead of xml
 * 
 * Date :13/10/2020
 * 
 */
package com.training.spring.demo;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
/** java config class annotated with Configuration */
@Configuration
public class Config {
	
	/*bean object creation getter method*/
	@Bean(name = "instrumentallist")
	public InstrumentalList geInstrumentalList() {
		
		InstrumentalList il = new InstrumentalList();
		il.setSaxophone(getSaxophone());
		return il;
		
	}
	/*bean object creation  getter method*/
	@Bean()
	public Saxophone getSaxophone() {
		
		Saxophone sp = new Saxophone();
		return sp;
	}

}
