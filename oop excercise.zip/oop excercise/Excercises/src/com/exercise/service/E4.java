package com.exercise.service;

import com.exercise.model.A;

public class E4 extends A{
	
	public static void main(String args[]) {
		
		//private int a = 222;
		int a = 222;
		System.out.println("In main():");
		System.out.println("a="+a);
	    a = 123;
	}
	
	
//change private
}
