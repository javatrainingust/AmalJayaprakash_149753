package com.exercise.service;

import com.exercise.model.A;

public class E3 {
	
public static void main(String args[]) {
		
		A objA = new A();
		double result;
		result = objA.getA();
		System.out.println("objA.a = "+result);
		
		//getting double value expecting int change double to int
	}

}
