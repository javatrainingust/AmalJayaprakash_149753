package com.exercise.service;

import com.exercise.model.A;

public class E2 {
	
	public static void main(String args[]) {
		
		
		System.out.println("In main():");
		//System.out.println("objA.a="+getA());
		//setA(123);
		A objA = new A();
		System.out.println("objA.a="+objA.getA());
	    objA.setA(222);
	}

}
