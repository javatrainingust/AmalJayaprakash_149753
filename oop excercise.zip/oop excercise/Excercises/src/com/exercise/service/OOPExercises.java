package com.exercise.service;

import com.exercise.model.A;
//EX 1.1
public class OOPExercises {
	
	public static void main(String args[]) {
		
		A objA = new A();
		System.out.println("In main():");
//		System.out.println("objA.a="+objA.a);
//		objA.a = 222;
		
		System.out.println("objA.a="+objA.getA());
		objA.setA(222);
	}

}
