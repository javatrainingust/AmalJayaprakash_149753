package com.exercise.model;

public class A {
	
	private int a = 100;
	
	public void setA(int value) {
		a = value;
	}
	
	public int getA() {
		return a;
	}

	
	
	

}
