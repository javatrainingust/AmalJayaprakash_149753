//package com.excercise1.service;
//
//import com.excercise1.model.A;
//import com.excercise1.model.B;
//
//public class E21 {
//	
//	public static void main(String args[]) {
//		
//		A objA = new A();
//		B objB = new B();
//		
//		System.out.println("in main():");
//		System.out.println("objA.a="+objA.getA());
//		System.out.println("objB.b="+objB.getB());
//		
//		objA.setA(222);
//		objB.setB(333.33);
//		
//		System.out.println("objA.a="+objA.getA());
//		System.out.println("objB.b="+objB.getB());
//	}
//
//}
