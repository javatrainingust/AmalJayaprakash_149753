package com.excercise1.model;

public class A {
	
	 int a = 100;
	
	public A() {
		
		//System.out.println("in the constructor of class A:");
		//System.out.println("a ="+a);
		a=333;
		//System.out.println("a ="+a);
		
	}
	

	public int getA() {
		return a;
	}

	public void setA(int value) {
		a = value;
	}
	
	

}
