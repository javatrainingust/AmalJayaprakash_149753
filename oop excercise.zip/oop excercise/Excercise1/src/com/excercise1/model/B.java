package com.excercise1.model;

public class B extends A {
	
 private int a = 123;
	
	public B() {
		
		//System.out.println("-----in the constructor of class B:");
		//System.out.println("b ="+b);
		//b=3.14159;
		a=2222;
		//System.out.println("b ="+b);
		
	}
	public void rollBackA() {
		a = super.getA();
	}
	public int getA() {
		return a;
	}
	public void setA(int value) {
		a = value;
	}

//	public double getB() {
//		return b;
//	}
//
//	public void setB(double value) {
//		b = value;
//	}
	
	

}
