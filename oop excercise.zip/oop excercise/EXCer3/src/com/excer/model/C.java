package com.excer.model;

public class C extends B{
	int a = 543;
	public void display() {
		
		System.out.printf("a in C = %d\n",a);
	}


}
