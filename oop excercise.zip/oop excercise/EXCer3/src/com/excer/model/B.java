package com.excer.model;

public class B extends A{
	int a = 123;
	public void display() {
		
		System.out.printf("a in B = %d\n",a);
	}


}
