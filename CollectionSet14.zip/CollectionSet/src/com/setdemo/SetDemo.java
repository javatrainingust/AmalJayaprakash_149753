package com.setdemo;

import java.util.HashSet;
import java.util.Set;

public class SetDemo {
	
	public static void main(String args[]) {
		String s1 = "test";
		String s2 = "work";
		String s3 = "test";
		
		Set<String> set = new HashSet<>();
		set.add(s1);
		set.add(s2);
		set.add(s3);
		
		for(String s : set) {
			System.out.println(s);
		}
		
		System.out.println();
		
		Cat cat1 = new Cat("rosy", 2);
		Cat cat2 = new Cat("pinky", 3);
		Cat cat3 = new Cat("rosy", 2);
		
		Set<Cat> catSet = new HashSet<Cat>();
		catSet.add(cat1);
		catSet.add(cat2);
		catSet.add(cat3);
		
		for(Cat cat : catSet) {
			System.out.println(cat);
		}
	}

}
