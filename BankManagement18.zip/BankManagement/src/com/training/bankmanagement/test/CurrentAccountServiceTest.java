package com.training.bankmanagement.test;

import static org.junit.Assert.*;



import org.junit.Test;

import com.training.bankmanagement.dao.CurrentAccountDAOImpl;
import com.training.bankmanagement.model.CurrentAccount;
import com.training.bankmanagement.service.CurrentAccountService;


public class CurrentAccountServiceTest {
	
	CurrentAccountService currentAccountService;


	
    public CurrentAccountServiceTest() {
	
    	currentAccountService = new CurrentAccountService();
    	currentAccountService.addCurrentAccount(new CurrentAccount(100, "anu",4000));
    	currentAccountService.addCurrentAccount(new CurrentAccount(101, "manu",1000));
    	currentAccountService.addCurrentAccount(new CurrentAccount(102, "vinu",2000));
    }
    
    @Test
	public void testAddCurrentAccountSuccess() {
    	currentAccountService.addCurrentAccount(new CurrentAccount(103,"roy",6000));
		int actual = currentAccountService.getAllCurrentAccounts().size();
		int expected = 4;
		assertEquals(expected, actual); 
			
		}
    
    @Test
	public void testAddCurrentAccountFailure() {
    	currentAccountService.addCurrentAccount(new CurrentAccount(102,"ginu",3000));
		String actual = currentAccountService.getCurrentAccountByAccountNumber(102).getAccountHolderName();
		System.out.println(actual);
		String expected = "vinu";
		assertEquals(expected, actual); 
			
		}
	

	@Test
	public void testGetAllCurrentAccounts() {
		
		int actual = currentAccountService.getAllCurrentAccounts().size();
		int expected = 3;
		assertEquals(expected, actual);
	}
	
	@Test
	public void testGetCurrentAccountByAccountNumber() {
		
		String actual = currentAccountService.getCurrentAccountByAccountNumber(100).getAccountHolderName();
		String expected = "anu";
		assertEquals(expected, actual);
	}
	
	@Test
	public void testDeleteCurrentAccount() {
		CurrentAccountDAOImpl currentAccountDAOImpl = new CurrentAccountDAOImpl();
		currentAccountDAOImpl.deleteCurrentAccount(102);;
		CurrentAccount actual = currentAccountDAOImpl.getCurrentAccountByAccountNumber(102);
		System.out.println(actual); 
		CurrentAccount expected = null;
		assertEquals(expected, actual);
	}
	
	@Test
	public void testGetAllCurrentAccountsSortByName() {
		
		String actual = currentAccountService.getAllCurrentAccountsSortedByName().get(0).getAccountHolderName();
		String expected = "anu";
		assertEquals(expected, actual);
	}
	
	@Test
	public void testGetAllCurretAccountsSortByOverdraftLimit() {
		
		String actual = currentAccountService.getAllCurrentAccountsSortedByOverdraftLimit().get(0).getAccountHolderName();
		System.out.println(actual);
		String expected = "manu";
		assertEquals(expected, actual);
	}
	
	@Test
	public void testUpdateCurrentAccount() {
		  
		currentAccountService.updateCurrentAccount(new CurrentAccount(102,"vinu",3500));
		float actual = currentAccountService.getCurrentAccountByAccountNumber(102).getOverDraftlimit();
		System.out.println(actual);
		float expected = 3500;
		assertEquals(expected, actual,0);
		
	}


}
