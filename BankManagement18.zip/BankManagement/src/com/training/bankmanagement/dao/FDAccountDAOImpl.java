/**
 * Classname:FDAccountDAOImpl
 * 
 * Description:This class is implemented from FDAccountDAO for data access operations
 *
 * Date:06/10/2020
 * 
*/
package com.training.bankmanagement.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.training.bankmanagement.model.FDAccount;
/**
*This is a class used for add,delete,get the fixed account detalis.
*/
public class FDAccountDAOImpl implements FDAccountDAO {
	
	List<FDAccount> fdAccountList;
	private Set<FDAccount> fdAccountSet;
	/**
	*constructor for FDAccountDAOImpl
	*/
	public FDAccountDAOImpl() { 
		
		fdAccountList = new ArrayList<FDAccount>();
		fdAccountSet = new HashSet<FDAccount>();
		
//		fdAccountList.add(new FDAccount(100, "anu",5000));
//		fdAccountList.add(new FDAccount(101, "manu",2000));
//		fdAccountList.add(new FDAccount(102, "vinu",3000));
		
	}
	/**
	*method for getting all fixed accounts
	*method implemented from FDAAccountDAO
	*/
	@Override
	public List<FDAccount> getAllFDAAccounts() {
		// TODO Auto-generated method stub
		return fdAccountList;
	}
	/**
	*method for getting fixed account details by account number
	*method implemented from FDAAccountDAO
	*/
	@Override
	public FDAccount getFDAAccountByAccountNumber(int accountNumber) {
		// TODO Auto-generated method stub
		FDAccount fdAccount = null;
		Iterator<FDAccount> iterator = fdAccountList.iterator();
		while(iterator.hasNext()) {
			
			FDAccount fd = iterator.next();
			
			if(fd.getAccountNumber() == accountNumber) {
				
				fdAccount = fd;
			}
		}
		return fdAccount;
	}
	/**
	*method for deleting fixed account by account number
	*method implemented from FDAAccountDAO
	*/
	@Override
	public void deleteFDAAccount(int accountNumber) {
		// TODO Auto-generated method stub
		for(int i = 0; i < fdAccountList.size(); i++) {
			
			FDAccount fd = fdAccountList.get(i);
			if(fd.getAccountNumber() == accountNumber) {
				
				fdAccountList.remove(i);
			}
		}
	}
	/**
	*method for adding fixed account 
	*method implemented from FDAAccountDAO
	*/
	@Override
	public boolean addFDAccount(FDAccount fdAccount) {
		// TODO Auto-generated method stub
		boolean isAdded = fdAccountSet.add(fdAccount);
		if(isAdded) {
			fdAccountList.add(fdAccount);
		}
		return isAdded;
	}
	
	/**
	*method for updating fixed account 
	*method implemented from FDAAccountDAO
	*/
	@Override
	public void updateFDAccount(FDAccount fdAccount) {
		// TODO Auto-generated method stub
		Iterator<FDAccount> iterator = fdAccountList.iterator();
		while(iterator.hasNext()) {
			FDAccount fd = iterator.next();
			
			if(fd.getAccountNumber() == fdAccount.getAccountNumber()) {
				
				fd.setAccountHolderName(fdAccount.getAccountHolderName());
				fd.setBalance(fdAccount.getBalance());
			}
			
		}
	}
	

}
