package com.training.bankmanagement.service;

public class LoanAccountDelete {
	
public static void main(String[] args) {
		
		LoanAccountService loanAccountService = new LoanAccountService();
		System.out.println("all loan accounts");
		loanAccountService.getAllLoanAccounts();
		System.out.println();
		
		loanAccountService.deleteLoanAccount(102);
		System.out.println("deleted");
		System.out.println("after deletion");
		loanAccountService.getAllLoanAccounts();
		
	}

}
