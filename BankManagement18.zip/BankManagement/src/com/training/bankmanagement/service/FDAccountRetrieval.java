package com.training.bankmanagement.service;

public class FDAccountRetrieval {
	
	public static void main(String[] args) {
		
		FDAccountService fdAccountService = new FDAccountService();
		System.out.println("all fixed accounts");
		fdAccountService.getAllFDAAccounts();
		System.out.println();
		System.out.println("fixed account details");
		fdAccountService.getFDAAccountByAccountNumber(100);
		
	}
	
	
	

}
