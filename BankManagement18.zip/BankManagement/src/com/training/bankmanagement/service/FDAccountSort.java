package com.training.bankmanagement.service;

public class FDAccountSort {
	
	public static void main(String args[]) {
		
		FDAccountService fdAccountService = new FDAccountService();
		System.out.println("All FD accounts");
		fdAccountService.getAllFDAAccounts();
		
		System.out.println();
		
		System.out.println("FD accounts sorted by a/c holder name");
		fdAccountService.getAllFDAccountsSortedByName();
		
		System.out.println();
		
		System.out.println("FD accounts sorted by balance");
		fdAccountService.getAllFDAccountsSortedByBalance();
	}

}
