package com.training.bankmanagement.service;

public class SBAccountDelete {
	
public static void main(String[] args) {
		
		SBAccountService sbAccountService = new SBAccountService();
		System.out.println("all savings accounts");
		sbAccountService.getAllSBAccounts();
		System.out.println();
		
		sbAccountService.deleteSBAccount(102);
		System.out.println("deleted");
		System.out.println("after deletion");
		sbAccountService.getAllSBAccounts();
		
	}

}
