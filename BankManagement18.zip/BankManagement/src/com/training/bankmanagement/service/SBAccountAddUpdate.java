package com.training.bankmanagement.service;

import com.training.bankmanagement.model.SBAccount;

public class SBAccountAddUpdate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SBAccountService sbAccountService = new SBAccountService();
		sbAccountService.addSBAccount(new SBAccount(100, "anu",15000));
		sbAccountService.addSBAccount(new SBAccount(101, "manu",22000));
		sbAccountService.addSBAccount(new SBAccount(102, "vinu",3000));
		System.out.println("before update");
		sbAccountService.getAllSBAccounts();
		sbAccountService.updateSBAccount(new SBAccount(102, "vinu",3500));
		System.out.println("after update");
		sbAccountService.getAllSBAccounts();
	}

}
