/**
 * Classname:SBAccountService
 * 
 * Description:This class forms sevices from data access class 
 *
 * Date:06/10/2020
 * 
*/
package com.training.bankmanagement.service;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.training.bankmanagement.dao.SBAccountDAO;
import com.training.bankmanagement.dao.SBAccountDAOImpl;
import com.training.bankmanagement.model.SBAccount;
/**
*This is a class used for add,delete,get the savings account detalis using data access class object.
*/
public class SBAccountService {
	
	SBAccountDAO sbAccountDAO;
	
 public SBAccountService() {
		
	sbAccountDAO = new SBAccountDAOImpl();
	}
	/**
	*method for getting all savings accounts using data access class object
	*
	*/
	public List<SBAccount> getAllSBAccounts() {
		
		List<SBAccount> sbAccountList = sbAccountDAO.getAllSBAccounts();
		
		Iterator<SBAccount> iterator = sbAccountList.iterator();
		
		while(iterator.hasNext()) {
			
			SBAccount sb = iterator.next();
			System.out.println("A/c no: "+sb.getAccountNumber());
			System.out.println("A/c holder name: "+sb.getAccountHolderName());
			System.out.println("A/c balance: "+sb.getBalance());
		}
		return sbAccountList;
	}
	/**
	*method for getting saving account details by account number using data access class object
	*
	*/
	public SBAccount getSBAccountByAccountNumber(int accountNumber) {
		
		SBAccount sb = sbAccountDAO.getSBAccountByAccountNumber(accountNumber);
		System.out.println("A/c no: "+sb.getAccountNumber());
		System.out.println("A/c holder name: "+sb.getAccountHolderName());
		System.out.println("A/c balance: "+sb.getBalance());
		
		return sb;
	}
	/**
	*method for deleting saving account by account number using data access class object
	*
	*/
	public void deleteSBAccount(int accountNumber) {
		sbAccountDAO.deleteSBAccount(accountNumber);
	}
	
	/**
	*method for sorting savings account by a/c holder name
	*
	*/
	public List<SBAccount> getAllSBAccountsSortedByName() {
		
		List<SBAccount> sbSortedList = sbAccountDAO.getAllSBAccounts();
		Collections.sort(sbSortedList);
		
		Iterator<SBAccount> iterator = sbSortedList.iterator();
		while(iterator.hasNext()) {
			
			SBAccount sb = iterator.next();
			System.out.println("A/c no: "+sb.getAccountNumber());
			System.out.println("A/c holder name: "+sb.getAccountHolderName());
			System.out.println("A/c balance: "+sb.getBalance());
		}
		return sbSortedList;
		
		
	}
	
	/**
	*method for sorting savings account by a/c balance
	*
	*/
	public List<SBAccount> getAllSBAccountsSortedByBalance() {
		
		List<SBAccount> sbSortedList = sbAccountDAO.getAllSBAccounts();
		Collections.sort(sbSortedList,new SBAccountComparator());
		
		Iterator<SBAccount> iterator = sbSortedList.iterator();
		while(iterator.hasNext()) {
			
			SBAccount sb = iterator.next();
			System.out.println("A/c no: "+sb.getAccountNumber());
			System.out.println("A/c holder name: "+sb.getAccountHolderName());
			System.out.println("A/c balance: "+sb.getBalance());
		}
		return sbSortedList;
		
		
	}
	
	/**
	*method for adding savings account 
	*
	*/
	public void addSBAccount(SBAccount sbAccount) {
		
		boolean isAdded = sbAccountDAO.addSBAccount(sbAccount);
		if(!isAdded) {
			System.out.println("this account alredy exist");
		}
		else {
			System.out.println("account added");
		}
	}
	
	/**
	*method for updating savings account 
	*
	*/
	public void updateSBAccount(SBAccount sbAccount) {
		
		sbAccountDAO.updateSBAccount(sbAccount);
		System.out.println("updated");
	}
	
	

}
