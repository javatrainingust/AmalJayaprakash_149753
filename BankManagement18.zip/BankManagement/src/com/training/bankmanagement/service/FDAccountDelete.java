package com.training.bankmanagement.service;

public class FDAccountDelete {
	
public static void main(String[] args) {
		
		FDAccountService fdAccountService = new FDAccountService();
		System.out.println("all fixed accounts");
		fdAccountService.getAllFDAAccounts();
		System.out.println();
		
		fdAccountService.deleteFDAAccount(102);
		System.out.println("deleted");
		System.out.println("after deletion");
		fdAccountService.getAllFDAAccounts();
		
	}
	

}
