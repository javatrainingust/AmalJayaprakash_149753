/**
 *Classs name: Signup
 * 
 * Desc: Class for modeling Signup
 * 
 * Date :15/10/2020
 * 
 */
package com.ust.training.springmvc.model;
/**
 * bean class for signup
 */
public class SignUp {
	
	private String userName;
	private String userId;
	private String password;
	private String confirmPassword;
	
	/* getters and setters method for attributes */
	public String getuserName() {
		return userName;
	}
	public void setuserName(String userName) {
		this.userName = userName;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

}
