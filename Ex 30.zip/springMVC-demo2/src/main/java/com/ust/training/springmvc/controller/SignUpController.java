/**
 *Classs name: SignUpController
 * 
 * Desc: Controller class
 * 
 * Date :15/10/2020
 * 
 */
package com.ust.training.springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;


import com.ust.training.springmvc.model.SignUp;
/** controller class for SignUpController */
@Controller
public class SignUpController {
	
	/* mapping method */
	@RequestMapping("/signup")
	public String signUp(Model model) {
		
		SignUp theSignUp = new SignUp();
		model.addAttribute("message", theSignUp);
		return "signup";
	}
	
	@RequestMapping("/processForm")
	public String process(@ModelAttribute("signUp") SignUp theSignUp) {
		
		return "confirmSignUp";
	}

}
