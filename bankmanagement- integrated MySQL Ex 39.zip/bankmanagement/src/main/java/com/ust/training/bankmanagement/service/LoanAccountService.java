/**
 * Classname:LoanAccountService
 * 
 * Description:This class forms sevices from data access class 
 *
 * Date:06/10/2020
 * 
*/
package com.ust.training.bankmanagement.service;

//import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.training.bankmanagement.dao.LoanAccountDAO;
import com.ust.training.bankmanagement.dao.LoanAccountDAOImpl;
import com.ust.training.bankmanagement.dao.LoanAccountDAOSQLImpl;
import com.ust.training.bankmanagement.model.LoanAccount;


/**
*This is a class used for add,delete,get the loan account detalis using data access class object.
*/
@Service
public class LoanAccountService {

	/* auto wiring dao class object */
	@Autowired
	LoanAccountDAO loanAccountDAO;
	/**
	*constructor for class 
	*/
	public LoanAccountService() {
			
		//loanAccountDAO = new LoanAccountDAOImpl();
		loanAccountDAO = (LoanAccountDAO) new LoanAccountDAOSQLImpl();
		
	}
		/**
		*method for getting all loan accounts using data access class object
		*
		*/
		public List<LoanAccount> getAllLoanAccounts() {
			
			List<LoanAccount> loanAccountList = loanAccountDAO.getAllLoanAccounts();
			
			Iterator<LoanAccount> iterator = loanAccountList.iterator();
			
			while(iterator.hasNext()) {
				
				LoanAccount la = iterator.next();
				System.out.println("A/c no: "+la.getAccountNumber());
				System.out.println("A/c holder name: "+la.getAccountHolderName());
				System.out.println("Loan out standing: "+la.getLoanOutStanding());
			}
			return loanAccountList;
		}
		/**
		*method for getting loan account details by account number using data access class object
		*
		*/
		public LoanAccount getLoanAccountByAccountNumber(int accountNumber) {
			
			LoanAccount la = loanAccountDAO.getLoanAccountByAccountNumber(accountNumber);
			System.out.println("A/c no: "+la.getAccountNumber());
			System.out.println("A/c holder name: "+la.getAccountHolderName());
			System.out.println("Loan out standing: "+la.getLoanOutStanding());
			
			return la;
		}
		/**
		*method for deleting loan account by account number using data access class object
		*
		*/
		public void deleteLoanAccount(int accountNumber) {
			loanAccountDAO.deleteLoanAccount(accountNumber);
		}
		
		/**
		*method for sorting loan account by a/c holder name
		*
		*/
		public List<LoanAccount> getAllLoanAccountsSortedByName() {
			
			List<LoanAccount> loanList = loanAccountDAO.getAllLoanAccounts();
			//Collections.sort(loanSortedList);
			/*using streams*/
			List loanSortedList = loanList.stream().sorted().collect(Collectors.toList());
			
			Iterator<LoanAccount> iterator = loanSortedList.iterator();
			while(iterator.hasNext()) {
				
				LoanAccount la = iterator.next();
				System.out.println("A/c no: "+la.getAccountNumber());
				System.out.println("A/c holder name: "+la.getAccountHolderName());
				System.out.println("Loan outstanding : "+la.getLoanOutStanding());
			}
			return loanSortedList;
			
			
		}
		
		/**
		*method for sorting loan account by loan outstanding
		*
		*/
		public List<LoanAccount> getAllLoanAccountsSortedByLoanOutstanding() {
			
			List<LoanAccount> loanList = loanAccountDAO.getAllLoanAccounts();
			
			//Collections.sort(loanSortedList, new LoanAccountComparator());
			/*using streams*/
			List loanSortedList = loanList.stream().sorted(new LoanAccountComparator()).collect(Collectors.toList());
			
			Iterator<LoanAccount> iterator = loanSortedList.iterator();
			while(iterator.hasNext()) {
				
				LoanAccount la = iterator.next();
				System.out.println("A/c no: "+la.getAccountNumber());
				System.out.println("A/c holder name: "+la.getAccountHolderName());
				System.out.println("Loan outstanding : "+la.getLoanOutStanding());
			}
			return loanSortedList;
			
			
		}
		
		/**
		*method for adding loan account 
		*
		*/
		public void addLoanAccount(LoanAccount loanAccount) {
			
			boolean isAdded = loanAccountDAO.addLoanAccount(loanAccount);
			if(!isAdded) {
				System.out.println("this account alredy exist");
			}
			else {
				System.out.println("account added");
			}
		}
		
		/**
		*method for updating loan account 
		*
		*/
		public void updateLoanAccount(LoanAccount loanAccount) {
			
			loanAccountDAO.updateLoanAccount(loanAccount);
			System.out.println("updated");
		}
		
		


}
