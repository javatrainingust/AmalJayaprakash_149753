/**
 * Classname:LoanAccountDAOSQLImpl
 * 
 * Description:This class is implemented from LoanAccountDAO for data access operations from MySQL database
 *
 * Date:23/10/2020
 * 
*/
package com.ust.training.bankmanagement.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ust.training.bankmanagement.model.LoanAccount;
import com.ust.training.bankmanagement.model.SBAccount;
/**
*This is a class used for add,delete,get the Loan account data access operations
*and forms Repository for Loan account.
*/
@Repository
public class LoanAccountDAOSQLImpl implements LoanAccountDAO{
	
	/*Declaring Datasource  */
	private DataSource dataSource;
	
	/*Declaring JDBC template */
	private JdbcTemplate jdbcTemplate;
	
	/**
	 * Constructor based dependency injection for Datasource
	 * creating a JdbcTemplate object using  datasource.
	 * */
	@Autowired
	public void setDataSource(DataSource dataSource) {
		
		this.dataSource = dataSource;
		
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	/**
	*method for getting all loan accounts
	*method implemented from LoanAccountDAO
	*/
	public List<LoanAccount> getAllLoanAccounts() {
		// TODO Auto-generated method stub
		String sql = "select * from loanaccount";
		
		List<LoanAccount> loanAccounts = jdbcTemplate.query(sql,new LoanAccountMapper());
		return loanAccounts;
	}
	
	/**
	*method for getting loan account details by account number
	*method implemented from LoanAccountDAO
	*/
	public LoanAccount getLoanAccountByAccountNumber(int accountNumber) {
		// TODO Auto-generated method stub
		String sql = "select * from loanaccount where accountnumber = ?";
		
		LoanAccount loanAccount = jdbcTemplate.queryForObject(sql, new Object[] 
				{accountNumber}, new LoanAccountMapper());
		
		return loanAccount;
	}
	
	/**
	*method for deleting loan  account by account number
	*method implemented from LoanAccountDAO
	*/
	public void deleteLoanAccount(int accountNumber) {
		// TODO Auto-generated method stub
		String sql = "delete from loanaccount where accountnumber = '"
				+accountNumber+"'";
		jdbcTemplate.update(sql);
		
	}
	
	/**
	*method for adding loan accounts
	*method implemented from LoanAccountDAO
	*/
	public boolean addLoanAccount(LoanAccount loanAccount) {
		// TODO Auto-generated method stub
		String sql = "insert into loanaccount" +
				 "(accountnumber, accountholdername, emi, loanoutstanding, tenture)"
				  +"VALUES (?, ?, ?, ?, ?)";
				
				jdbcTemplate.update(sql, new Object[] {
						loanAccount.getAccountNumber(),
						loanAccount.getAccountHolderName(),
						loanAccount.getEMI(),
						loanAccount.getLoanOutStanding(),
						loanAccount.getTenture()});
				return true;
	}
	
	/**
	*method for updating loan accounts
	*method implemented from LoanAccountDAO
	*/
	public void updateLoanAccount(LoanAccount loanAccount) {
		// TODO Auto-generated method stub
		String sql = "update loanaccount set accountholdername = '"+loanAccount.getAccountHolderName()
		+"', tenture = '"+loanAccount.getTenture()+"' "
				+ "where accountnumber = '"+loanAccount.getAccountNumber()+"'";
		
		jdbcTemplate.update(sql);
		
	}

}
