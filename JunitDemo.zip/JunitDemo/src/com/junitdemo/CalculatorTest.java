package com.junitdemo;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalculatorTest {

	@Test
	public void testAdd() {
		
		int expected = 8;
		
		Calculator calculator = new Calculator();
		
		int actual = calculator.add(6, 2);
		
		assertEquals(expected, actual);
	}
	
	@Test
	public void testSubtract() {
		
		int expected = 7;
		
		Calculator calculator = new Calculator();
		
		int actual = calculator.subtract(10, 3);
		
		assertEquals(expected, actual);
	}

}
