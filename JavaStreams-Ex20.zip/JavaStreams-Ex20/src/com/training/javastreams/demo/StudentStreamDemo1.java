package com.training.javastreams.demo;

import java.util.Arrays;
import java.util.stream.Stream;

public class StudentStreamDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] students = {"Vinoth", "Suresh", "Jane", "Roshan"};
		
		Stream<String> studentStream = Arrays.stream(students);
		System.out.println(studentStream);
		long studentCount = studentStream.count();
		System.out.println("counts :" +studentCount);

	}

}
