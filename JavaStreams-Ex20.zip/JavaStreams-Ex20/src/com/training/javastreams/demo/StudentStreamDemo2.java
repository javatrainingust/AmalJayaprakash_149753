package com.training.javastreams.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class StudentStreamDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> studentList = new ArrayList<>();
		studentList.add("Vinoth");
		studentList.add("Suresh");
		studentList.add("Jane");
		studentList.add("Roshan");
		
		Stream<String> studentStream = studentList.stream();
		long studentCount = studentStream.count();
		
		System.out.println("Student count :" +studentCount);
		

	}

}
