package com.collectiondemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class CatMain {
	
	public static void main(String args[]) {
		
		List<Cat> catList = new ArrayList<>();
		catList.add(new Cat("kitty", 2));
		catList.add(new Cat("rose", 3));
		catList.add(new Cat("nikki", 1));
		
		Iterator<Cat> catIterator = catList.iterator();
		while(catIterator.hasNext()) {
			
			System.out.println(catIterator.next());
		}
		System.out.println();
		System.out.println("sorted by age");
		
		Collections.sort(catList);
		
		Iterator<Cat> catIterator1 = catList.iterator();
		while(catIterator1.hasNext()) {
			
			System.out.println(catIterator1.next());
		}
	}

}
