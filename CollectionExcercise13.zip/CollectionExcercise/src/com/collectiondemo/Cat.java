/**
 * Classname:Cat
 * 
 * Description:this class is implemented from Comparable
 *
 * Date:05/10/2020
 * 
*/
package com.collectiondemo;
/**
*This is a class used to model Cat's details.
*/
public class Cat implements Comparable<Cat>{
	
	private Integer age;
	private String name;
	
	/*no arg constructor*/
	public Cat() {
		
	}
	/*param constructor*/
	public Cat(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}


	@Override
	public String toString() {
		return "Cat [name=" + name + ", age=" + age + "]";
	}
	/*method for comparing age of cats*/
	@Override
	public int compareTo(Cat c) {
		// TODO Auto-generated method stub
		return age.compareTo(c.age);
	}
	
	
	
	

}
