package com.collectiondemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StudentsMain {
	
	public static void main(String args[]) {
		
		List<String> student = new ArrayList<String>();
		student.add("Vivek");
		student.add("Vijay");
		student.add("Ajith");
		student.add("Surya");
		
		for(String s : student) {
			System.out.println("student name :" +s);
		}
		
		System.out.println("sorted names");
		Collections.sort(student);
		for(String s : student) {
			System.out.println("student name :" +s);
		}
		
		
		
	}

}
