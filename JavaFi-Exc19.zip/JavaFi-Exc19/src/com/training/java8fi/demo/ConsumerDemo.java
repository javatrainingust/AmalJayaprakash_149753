package com.training.java8fi.demo;

import java.util.function.Consumer;

public class ConsumerDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Consumer<String> toUpper = (s) -> {
			
			System.out.println(s.toUpperCase());
		};
		System.out.println("amal to uppercase:");
		toUpper.accept("amal");
	}

}
