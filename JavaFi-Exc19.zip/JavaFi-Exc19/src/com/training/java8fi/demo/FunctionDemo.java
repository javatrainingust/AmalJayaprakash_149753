package com.training.java8fi.demo;

import java.util.function.Function;

public class FunctionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Function<String, String> toUpper = (s) -> {
			return s.toUpperCase();
		};
		
		System.out.println("amal to upper case :" +toUpper.apply("amal"));
		

	}

}
