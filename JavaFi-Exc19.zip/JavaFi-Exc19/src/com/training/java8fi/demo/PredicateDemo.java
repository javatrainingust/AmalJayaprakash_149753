package com.training.java8fi.demo;

import java.util.function.Predicate;

public class PredicateDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Predicate<Integer> isGreaterThan50 = (i) -> {
			
			if(i>50) {
				return true;
			}
			else {
				return false;
			}
		};
		
		System.out.println("is 55 greater than 50 :" +isGreaterThan50.test(55));
		System.out.println("is 40 greater than 50 :" +isGreaterThan50.test(40));
	}

}
