package com.training.java8fi.demo;

import java.util.function.Supplier;

public class SupplierDemo {
	
	public static void main(String args[]) {
		
		double rn = Math.random();
		Supplier<Double> randomNumber = () -> rn;
		
		System.out.println("random no :" +randomNumber.get());
	}

}
