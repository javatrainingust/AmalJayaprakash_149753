package com.java8features;

public interface CheckValue {
	
	public boolean check(int n);

}
