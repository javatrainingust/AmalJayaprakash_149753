package com.java8features;

public interface NumCalculator {
	
	public int getValue(int a, int b);

}
