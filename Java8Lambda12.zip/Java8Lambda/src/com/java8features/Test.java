package com.java8features;

public interface Test {
	
	public void test();

}
