package com.java8features;

public class Main {
	
	public static void main(String args[]) {
		
		CheckValue isEven = (c) -> c%2 == 0;
		
		if(isEven.check(4)) {
			System.out.println("even number");
		}
		
		else {
			System.out.println("odd number");
		}
		
		System.out.println("*****");
		
		DisplayResult displayResult = (d) -> System.out.println(d);
		displayResult.display("hey");
		
		System.out.println("*****");
		
		NumCalculator numCalculator = (n1,n2) -> {
			
			System.out.println(n1*n2);
			return n1*n2;
		};
		numCalculator.getValue(10, 10);
		
		System.out.println("*****");
		
		Test test1 =() -> System.out.println("4 * 6 ="+(4*6));
		test1.test();
		
		

	}

}
