package com.bankmanagement.model;

public class Account {
	
	private int accountNumber;
	private String accountHolderName;
	private float balance;
	protected float intr;
	protected float simpleIntr;
	//private float principal;
	

	
	public int getAccountNumber() {
		return accountNumber;
	}



	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}



	public String getAccountHolderName() {
		return accountHolderName;
	}



	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}



	public float getBalance() {
		return balance;
	}



	public void setBalance(float balance) {
		this.balance = balance;
	}



	public float getIntr() {
		return intr;
	}



	public void setIntr(float intr) {
		this.intr = intr;
	}



	public void withdrawMoney(int amountToWithdraw) {
		
		this.balance = this.balance - amountToWithdraw;
		
	}
	
	public void calculateInterest() {
		
		System.out.println("calculating interest");
	}
	

}
