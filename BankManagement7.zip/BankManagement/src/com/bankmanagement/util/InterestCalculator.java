package com.bankmanagement.util;

/**...
 * InterestCalculator
 * providing methods for implementing in classes that 
 	implements InterestCalculator	
 * 30/09/2020
 * */

public interface InterestCalculator {
	
	public float calculateSimpleInterest(double rate);
	
	public float calculateSimpleInterest(double rate, float additional);
	

}
