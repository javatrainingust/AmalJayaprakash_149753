/**
 *Classs name: Guitar
 * 
 * Desc: Implemented from Instrument interface
 * 
 * Date :12/10/2020
 * 
 */
package com.training.spring.demo;
/** bean class for guitar */
public class Guitar implements Instrument{
	/* method implemented from instrument*/
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("playing guitar");
	}

}
