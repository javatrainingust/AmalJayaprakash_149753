/**
 *Classs name: OneManBand
 * 
 * Desc: Implemented from Performer interface
 * 
 * Date :12/10/2020
 * 
 */
package com.training.spring.demo;

import java.util.Iterator;
import java.util.List;
/* bean class for one man band */
public class OneManBand implements Performer {
	
	List<Instrument> instrument;
	
	
	/*getters and setters for
	 * dependency injection
	 */
	
	public List<Instrument> getInstrument() {
		return instrument;
	}



	public void setInstrument(List<Instrument> instrument) {
		this.instrument = instrument;
	}


	/* method implemented from Perform*/
	public void perform() {
		// TODO Auto-generated method stub
		Iterator<Instrument> iterator = instrument.iterator();
		while(iterator.hasNext()) {
			
			Instrument instrument = (Instrument) iterator.next();
			instrument.play();
		}
	}

}
