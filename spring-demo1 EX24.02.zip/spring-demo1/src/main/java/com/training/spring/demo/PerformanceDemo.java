/**
 *Classs name: PerformanceDemo
 * 
 * Desc: main class
 * 
 * Date :12/10/2020
 * 
 */
package com.training.spring.demo;

import org.springframework.context.support.ClassPathXmlApplicationContext;
/* class for loading bean file and injecting value */
public class PerformanceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		/* getting Singer object from spring container */
		Singer singer = context.getBean("singer", Singer.class);
		singer.perform();
		/* getting Instrmental list object from spring container */
		InstrumentalList instrumentalList = context.getBean("instrumentallist", InstrumentalList.class);
		instrumentalList.perform();
		
	}

}
