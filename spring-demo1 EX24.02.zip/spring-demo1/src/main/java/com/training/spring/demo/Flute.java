/**
 *Classs name: Flute
 * 
 * Desc: Implemented from Instrument interface
 * 
 * Date :12/10/2020
 * 
 */
package com.training.spring.demo;
/** bean class for flute */
public class Flute implements Instrument {
	
	/* method implemented from instrument*/
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("playing flute");
	}

}
