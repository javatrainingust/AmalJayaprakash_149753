/**
 *Interface name: Instrument
 * 
 * Desc: Interface for implementing in future classes
 * 
 * Date :12/10/2020
 * 
 */
package com.training.spring.demo;
/** interface declaring methods */
public interface Instrument {
	
	public void play();

}
