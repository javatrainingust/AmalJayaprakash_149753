/**
 * Class name: SBAccountController
 * 
 * Desc: Controller class for SB Account
 *
 * Date : 22/10/2020
 * 
*/
package com.ust.training.bankmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ust.training.bankmanagement.model.SBAccount;
import com.ust.training.bankmanagement.service.SBAccountService;

/** controller class for mapping operations annotated with @RestController 
 * forms rest services for SB Account
 * */
@RestController
public class SBAccountController {
	
	/* autowiring SB account service object */
	@Autowired
	SBAccountService sbService;
	
	
	/** for creating SB Account */
	@RequestMapping(value = "/sbAccounts", method=RequestMethod.POST)
	public SBAccount addSBAccount(@RequestBody SBAccount sbAccount) {
		
		sbService.addSBAccount(sbAccount);
		
		return sbAccount;
	}
	
	/** updating  SB account  */
	@RequestMapping(value = "/sbAccounts/{acno}", method=RequestMethod.PUT)
	public SBAccount updateSBAccount(@PathVariable int acno, 
			@RequestBody SBAccount sbAccount) {
		
		SBAccount oldSBAccount = sbService.getSBAccountByAccountNumber(acno);
		
		if(oldSBAccount != null) {
			
			sbService.updateSBAccount(sbAccount);
		}
		return sbAccount;
	}
	
	/** getting all SB account details */
	@RequestMapping(value = "/sbAccounts", method=RequestMethod.GET)
	public List<SBAccount> getAllSBAccounts() {
		
		List<SBAccount> sbList = sbService.getAllSBAccounts();
		
		return sbList;
	}
	
	/** getting specific SB account details */
	@RequestMapping(value = "/sbAccounts/{acno}", method=RequestMethod.GET)
	public SBAccount getSBAccountByAccountNumber(@PathVariable int acno) {
		
		SBAccount sbAccount = sbService.getSBAccountByAccountNumber(acno);
		
		return sbAccount;
		
	}
	
	/** deleting specific SB account details */
	@RequestMapping(value = "/sbAccounts/{acno}", method=RequestMethod.DELETE)
	public String deleteSBAccountByAccountNumber(@PathVariable int acno) {
		
		sbService.deleteSBAccount(acno);
		
		return "deleted SB Account with A/C no "+acno;
		
		
	}
	
	/** sort SB account by A/c holder name */
	@RequestMapping("/sortsbaccountbyname")
	public String getAllSBAccountsSortedByName(Model model) {
		
		List<SBAccount> sorted = sbService.getAllSBAccountsSortedByName();
		model.addAttribute("sbaccounts", sorted);
		return "sbAccount";
	}
	
	/* sort SB account by balance */
	@RequestMapping("/sortsbaccountbybalance")
	public String getAllSBAccountsSortedByBalance(Model model) {
		
		List<SBAccount> sorted = sbService.getAllSBAccountsSortedByBalance();
		model.addAttribute("sbaccounts", sorted);
		return "sbAccount";
	}
	
	

}
