/**
 *Classs name: SpringDemo
 * 
 * Desc: main class
 * 
 * Date :12/10/2020
 * 
 */
package com.training.spring.demo;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		Organizer organizer = context.getBean("organizer", Organizer.class);
		organizer.sayGreetings();
	}

}
