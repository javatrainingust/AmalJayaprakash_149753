/**
 *Classs name: Organizer
 * 
 * Desc: bean class for Organizer
 * 
 * Date :12/10/2020
 * 
 */
package com.training.spring.demo;
/* class for loading bean file  */
public class Organizer {
	
	public void sayGreetings() {
		
		System.out.println("Welcome to the talent competion");
	}

}
