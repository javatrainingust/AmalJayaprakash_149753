/**
 * Classname:InsufficentBalanceException
 * 
 * Description:This class is implemented from Exception class
 *
 * Date:09/10/2020
 * 
*/
package com.ust.training.bankmanagement.exception;

/**
*This is a class used to define custom exception for insufficient balance.
*/
public class InsufficentBalanceException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	float amountToWithdraw;
	/**
	*param  constructor 
	*/
	public InsufficentBalanceException(float amountToWithdraw) {
		
		this.amountToWithdraw = amountToWithdraw;
	}
	
	public String toString() {
		
		return "you dont have enough balance ";
	}

}
