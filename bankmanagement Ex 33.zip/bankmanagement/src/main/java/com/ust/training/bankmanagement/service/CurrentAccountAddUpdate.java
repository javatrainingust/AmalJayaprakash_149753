package com.ust.training.bankmanagement.service;

import com.ust.training.bankmanagement.model.CurrentAccount;

public class CurrentAccountAddUpdate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CurrentAccountService currentAccountService = new CurrentAccountService();
		currentAccountService.addCurrentAccount(new CurrentAccount(100, "anu",4000));
		currentAccountService.addCurrentAccount(new CurrentAccount(101, "manu",1000));
		currentAccountService.addCurrentAccount(new CurrentAccount(102, "vinu",2000));
		System.out.println("before update");
		currentAccountService.getAllCurrentAccounts();
		currentAccountService.updateCurrentAccount(new CurrentAccount(102, "vinu",2500));
		System.out.println("after update");
		currentAccountService.getAllCurrentAccounts();
	}

	

}
