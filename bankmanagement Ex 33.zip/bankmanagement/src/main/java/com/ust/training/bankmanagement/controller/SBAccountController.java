/**
 * Class name: SBAccountController
 * 
 * Desc: Controller class for SB Account
 *
 * Date : 15/10/2020
 * 
*/
package com.ust.training.bankmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


import com.ust.training.bankmanagement.model.SBAccount;
import com.ust.training.bankmanagement.service.SBAccountService;

/** for mapping SB account operations */
@Controller
public class SBAccountController {
	
	/* autowiring SB account service object */
	@Autowired
	SBAccountService sbService;
	
	/* getting all SB account details */
	@RequestMapping("/allsbaccounts")
	public String getAllSBAccounts(Model model) {
		
		List<SBAccount> sb = sbService.getAllSBAccounts();
		model.addAttribute("sbaccounts", sb);
		
		return "sbAccount";
	}
	
	/* getting specific SB account details */
	@RequestMapping("/viewsbaccount")
	public String getSBAccountByAccountNumber(@RequestParam("acno") int acno, Model model) {
		
		SBAccount sb = sbService.getSBAccountByAccountNumber(acno);
		model.addAttribute("sbaccounts1", sb);
		
		return "viewSBAccount";
		
	}
	
	/* deleting specific SB account details */
	@RequestMapping("/deletesbaccount")
	public String deleteSBAccountByAccountNumber(@RequestParam("acno") int acno) {
		
		sbService.deleteSBAccount(acno);
		
		return "redirect:/allsbaccounts";
		
	}
	
	

}
