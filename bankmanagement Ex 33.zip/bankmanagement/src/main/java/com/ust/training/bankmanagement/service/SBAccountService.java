/**
 * Classname:SBAccountService
 * 
 * Description:This class forms sevices from data access class 
 *
 * Date:06/10/2020
 * 
*/
package com.ust.training.bankmanagement.service;

//import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.training.bankmanagement.dao.SBAccountDAO;
import com.ust.training.bankmanagement.dao.SBAccountDAOImpl;
import com.ust.training.bankmanagement.exception.InsufficentBalanceException;
import com.ust.training.bankmanagement.model.SBAccount;
/**
*This is a class used for add,delete,get the savings account detalis using data access class object.
*/
@Service
public class SBAccountService {
	/* auto wiring dao class object */
	@Autowired
	SBAccountDAO sbAccountDAO;
	SBAccount sbAccount;
	
 public SBAccountService() {
		
	sbAccountDAO = new SBAccountDAOImpl();
	sbAccount = new SBAccount();
	}
	/**
	*method for getting all savings accounts using data access class object
	*
	*/
	public List<SBAccount> getAllSBAccounts() {
		
		List<SBAccount> sbAccountList = sbAccountDAO.getAllSBAccounts();
		
		Iterator<SBAccount> iterator = sbAccountList.iterator();
		
		while(iterator.hasNext()) {
			
			SBAccount sb = iterator.next();
			System.out.println("A/c no: "+sb.getAccountNumber());
			System.out.println("A/c holder name: "+sb.getAccountHolderName());
			System.out.println("A/c balance: "+sb.getBalance());
		}
		return sbAccountList;
	}
	/**
	*method for getting saving account details by account number using data access class object
	*
	*/
	public SBAccount getSBAccountByAccountNumber(int accountNumber) {
		
		SBAccount sb = sbAccountDAO.getSBAccountByAccountNumber(accountNumber);
		System.out.println("A/c no: "+sb.getAccountNumber());
		System.out.println("A/c holder name: "+sb.getAccountHolderName());
		System.out.println("A/c balance: "+sb.getBalance());
		
		return sb;
	}
	/**
	*method for deleting saving account by account number using data access class object
	*
	*/
	public void deleteSBAccount(int accountNumber) {
		sbAccountDAO.deleteSBAccount(accountNumber);
	}
	
	/**
	*method for sorting savings account by a/c holder name
	*
	*/
	public List<SBAccount> getAllSBAccountsSortedByName() {
		
		List<SBAccount> sbList = sbAccountDAO.getAllSBAccounts();
		//Collections.sort(sbSortedList);
		/*using streams*/
		List sbSortedList = sbList.stream().sorted().collect(Collectors.toList());
		
		Iterator<SBAccount> iterator = sbSortedList.iterator();
		while(iterator.hasNext()) {
			
			SBAccount sb = iterator.next();
			System.out.println("A/c no: "+sb.getAccountNumber());
			System.out.println("A/c holder name: "+sb.getAccountHolderName());
			System.out.println("A/c balance: "+sb.getBalance());
		}
		return sbSortedList;
		
		
	}
	
	/**
	*method for sorting savings account by a/c balance
	*
	*/
	public List<SBAccount> getAllSBAccountsSortedByBalance() {
		
		List<SBAccount> sbList = sbAccountDAO.getAllSBAccounts();
		//Collections.sort(sbSortedList,new SBAccountComparator());
		/*using streams*/
		List sbSortedList = sbList.stream().sorted(new SBAccountComparator()).collect(Collectors.toList());
		
		Iterator<SBAccount> iterator = sbSortedList.iterator();
		while(iterator.hasNext()) {
			
			SBAccount sb = iterator.next();
			System.out.println("A/c no: "+sb.getAccountNumber());
			System.out.println("A/c holder name: "+sb.getAccountHolderName());
			System.out.println("A/c balance: "+sb.getBalance());
		}
		return sbSortedList;
		
		
	}
	
	/**
	*method for adding savings account 
	*
	*/
	public void addSBAccount(SBAccount sbAccount) {
		
		boolean isAdded = sbAccountDAO.addSBAccount(sbAccount);
		if(!isAdded) {
			System.out.println("this account alredy exist");
		}
		else {
			System.out.println("account added");
		}
	}
	
	/**
	*method for updating savings account 
	*
	*/
	public void updateSBAccount(SBAccount sbAccount) {
		
		sbAccountDAO.updateSBAccount(sbAccount);
		System.out.println("updated");
	}
	
	
	/**
	*method for with drawing money with try and catch for exception handling
	*
	*/
	public float withdrawMoney(float amountToWithdraw) {
		
		try {
			
			sbAccount.withdrawMoney(amountToWithdraw);
			return sbAccount.getBalance();
			
		} catch (InsufficentBalanceException e) {
			// TODO: handle exception
			System.out.println("Insufficient balance");
			return sbAccount.getBalance();
		}
	}
	
	

}
