/**
 * Interface name:SBAccountDAO
 * 
 * Description:This interface is form data access operations
 *
 * Date:06/10/2020
 * 
*/
package com.ust.training.bankmanagement.dao;

import java.util.List;

import com.ust.training.bankmanagement.model.SBAccount;
/**
*This interface declare data access operations in SB.
*/
public interface SBAccountDAO {
	
	public List<SBAccount> getAllSBAccounts();
	public SBAccount getSBAccountByAccountNumber(int accountNumber);
	public void deleteSBAccount(int accountNumber);
	public boolean addSBAccount(SBAccount sbAccount);
	public void updateSBAccount(SBAccount sbAccount);

}
