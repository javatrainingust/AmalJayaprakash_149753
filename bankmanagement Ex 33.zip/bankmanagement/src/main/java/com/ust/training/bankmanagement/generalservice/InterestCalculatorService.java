package com.ust.training.bankmanagement.generalservice;

import com.ust.training.bankmanagement.model.FDAccount;
import com.ust.training.bankmanagement.model.SBAccount;
import com.ust.training.bankmanagement.util.InterestCalculatorImpl;

public class InterestCalculatorService {
	
	public static void main(String args[]) {
		
		FDAccount fdAccount = new FDAccount();
		fdAccount.setAccountHolderName("Rejin");
		fdAccount.setAccountNumber(296);
		fdAccount.setRate(5);
		fdAccount.setAdditional(10);
		System.out.println("a/c holder :"+fdAccount.getAccountHolderName());
		System.out.println("a/c no :"+fdAccount.getAccountNumber());
		
		InterestCalculatorImpl interestCalculatorImpl = new InterestCalculatorImpl();
		fdAccount.calculateSimpleInterest(interestCalculatorImpl);
		//fdAccount.calculateSimpleInterest();
		
		System.out.println();
		
		SBAccount sbAccount = new SBAccount();
		sbAccount.setAccountHolderName("jeeva");
		sbAccount.setAccountNumber(326);
		sbAccount.setRate(5);
		System.out.println("a/c holder :"+sbAccount.getAccountHolderName());
		System.out.println("a/c no :"+sbAccount.getAccountNumber());
		
		
		sbAccount.calculateSimpleInterest(interestCalculatorImpl);
		
	}

}
