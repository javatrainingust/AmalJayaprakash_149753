/**
 *Classs name: Singer
 * 
 * Desc: Implemented from Perform interface
 * 
 * Date :12/10/2020
 * 
 */
package com.training.spring.demo;
/* bean class for singer */
public class Singer implements Performer{
	
	private String song;
	
	/*param constrctor
	 * dependency injection
	 */
	public Singer(String song) {
		super();
		this.song = song;
	}

	/* method implemented from Perform*/
	public void perform() {
		// TODO Auto-generated method stub
		System.out.println(song);
		
	}
	
	

}
