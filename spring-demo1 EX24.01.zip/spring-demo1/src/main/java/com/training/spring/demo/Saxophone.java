/**
 *Classs name: Saxophone
 * 
 * Desc: Implemented from Instrument interface
 * 
 * Date :12/10/2020
 * 
 */
package com.training.spring.demo;
/* bean class for saxophone */
public class Saxophone implements Instrument {
	
	/* method implemented from instrument*/
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("playing saxophone");
		
	}

}
